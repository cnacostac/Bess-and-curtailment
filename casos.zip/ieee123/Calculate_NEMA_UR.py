# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 11:26:15 2020

@author: lanal
"""


Vne=[]
Vnema=[]
Vu3phmax=[]
for ibus in range(len(Data_Customers['all_bus_names'])):
    opendss.DSSCircuit.SetActiveBus(str(Data_Customers['all_bus_names'][ibus]))
    V123=opendss.DSSCircuit.ActiveBus.puVmagAngle
    if opendss.DSSCircuit.ActiveBus.NumNodes == 1:
        Vu3ph=0
    if opendss.DSSCircuit.ActiveBus.NumNodes == 2:
        Vu3ph=((np.add(V123[0],V123[2])/2-min(V123[0],V123[2]))/(np.add(V123[0],V123[2])/2))*100
    if opendss.DSSCircuit.ActiveBus.NumNodes == 3:
        Vu3ph=((np.add(V123[4],np.add(V123[0],V123[2]))/3-min(V123[0],V123[2],V123[4]))/(np.add(V123[4],np.add(V123[0],V123[2]))/3))*100
    Vnema=[Vu3ph,ibus,ie,iep,iMC]
#    if Vnema[0] >= Vu3phmax[0]:
#        Vu3phmax=Vnema
    Vne.append(Vnema[0])
Vu3phmax.append(Vne)#=[np.max(Vnema),np.argmax(Vnema)]
        
