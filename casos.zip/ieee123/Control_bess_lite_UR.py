# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 21:44:25 2019

@author: Nallely Acosta TECNM/Instituto Tecnológico de Morelia
"""
import statistics
import matplotlib
import numpy as np
import numpy
import matplotlib.pyplot as plt #abrir figuras en ventanas
import math
import re
import pandas as pd
import random
from matplotlib import collections  as mc
import opendss_class as opendss
from random import seed
from random import choice
from random import sample
import matplotlib.cm as cm
import time
import os
import heapq
import datetime as dt
opendss = opendss.opendss()
import datetime
import matplotlib as mpl
import matplotlib as mpl


currentDT = datetime.datetime.now()
print (str(currentDT))

t = time.process_time()
## Define the path where files are located


mydir = 'C:/Users/Usersname/casos/ieee123'
Read_excel = 'C:\\Users\\Username\\casos\\ieee123\\'
PVprofiles = '(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Norm_PV_Prof\\Nprofile_'
Loadprofiles = '(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Norm_Load_Prof\\Nprofile_'


LoadMult=1
GenMult1=1
gencur_adj=0.01
gencur_adjup=0.01
gen_min=0.7

# 10 min T=1, 15 min T=2, 20 min T=3
T=1

vpu_tol=0.01
ur_tol=0.5
case_name='IEEE_123_'+str(LoadMult)
#['PVSize_data', [1, 5, 10, 30, 50, 100, 500]],\
## Basic definitions
#30,20,20,1,1,1, 1, 13, 13      43,21,20,1,1,1, 1, 9, 5
# Tarifas 
# GDMTH	Gran Demanda en Media Tensión horaria	HM, HMC, 6   demanda >= 100 kW
# GDMTO	Gran Demanda en Media Tensión ordinaria	OM, 6        demanda >= 10 kW
# RAMT	Riego Agrícola en Media Tensión	9M




Data_Case=dict([\
                ['SE_CAP', 5],\
                ['hours', 288],\
                ['BatterySize_data', np.divide([4, 4, 8, 24, 36,48,132,252],1)],\
                ['BatteryMaxRate_data', np.divide([1.6, 1.6, 3.2, 9.6, 14.4,19.2,52.8,100.8],1)],\
                ['PVSize_data', np.divide([1, 5, 10, 30, 50,100,250,500],1)],\
                ['PV_minH', 50],\
                ['Vlimit_pu', [0.93, 1.05]],\
                ['UR_Maxim%', 2],\
                ['Resolution_std-data', [10, 5]],\
                ['%-Cumplimiento-Tension', 95],\
                ['OverCurrentLimit', np.divide(65,100)],\
                ['CurrentLimit_%', 80],\
                ['SubestationSLimit_%', np.divide(80,100)],\
                ['TransformerSLimit_%', np.divide(80,100)],\
                ['Buses(0)_Nodes(1)', [0]],\
		['WiresData', []],\
                ['CableData', []],\
                ['Lines', []],\
                ['Geometries', []],\
                ['Loads', []],\
                ['Loads_Daily', []],\
                ['Large_Customers', []],\
                ['Large_Customers_Daily', []],\
                ['Load_Shapes', []],\
                ['PV_Shapes', []],\
                ['Battery_refSoC_ini',10],\
                ['Battery_refSoC', 90],\
                ['Battery_minSoC', 5],\
                ['Battery_minresSoC', 10],\
                ['Battery_maxSoC', 90],\
                ])

exec(open(mydir +'/'+'Read_Circuit_info.py').read())
exec(open(mydir +'/'+'Call_Dict2.py').read())


Data_PV['Baxe_battery_history']=[]
Data_Impact=dict([\
                ['Pmax', 100],\
                ['itera', 0],\
                ['Per_actual', 0],\
                ['PerPen', [71]],\
                ['MonteCarlo_Iterations',1],\
                ])
#Data_Impact['PerPen']=np.arange(1,101)
#Data_Impact['PerPen']=np.arange(1,2)

PV_sizes=[]
BESS_sizes=[]
for i in range(len(Data_Case['PVSize_data'])):
    if Data_Case['PVSize_data'][i] >= Data_Case['PV_minH']:
        PV_sizes.append(Data_Case['PVSize_data'][i])
        BESS_sizes.append(Data_Case['BatterySize_data'][i])
PV_sizes=PV_sizes[::-1]        
Data_PV['Hierarchical']=[]

#%%
## ****************************************************************************
#                                        Initialize OpenDSS
# *****************************************************************************
import DSSStartup as dsss
DSSStartOK, DSSObj, DSSText = dsss.DSSStartup()
if not DSSStartOK:
    print('Unable to start the OpenDSS Engine')
    import sys
    sys.exit()

DSSText = DSSObj.Text                                                          #   Set up the Text
DSSText.Command = 'set DefaultBaseFrequency=60'
DSSText.Command = 'clear'
DSSCircuit = DSSObj.ActiveCircuit                                              #   Set up the Circuit
DSSSolution = DSSCircuit.Solution                                              #   Set up the Solution
ControlQueue = DSSCircuit.CtrlQueue                                            #   Set up the Control
DSSObj.AllowForms = 0 

###############################################################################
#  Llamar a los archivos txt
DSSText.Command = 'New circuit.ieee123 basekv=4.16 Bus1=150 pu=1.00 R1=0 X1=0.0001 R0=0 X0=0.0001'
DSSText.Command = 'new transformer.reg1a phases=3 windings=2 buses=[150 150r] conns=[wye wye] kvs=[4.16 4.16] kvas=[5000 5000] XHL=.001 %LoadLoss=0.00001 ppm=0.0' #red primaria
DSSText.Command = 'new regcontrol.creg1a transformer=reg1a winding=2 vreg=120 band=2 ptratio=20 ctprim=700 R=3 X=7.5'
DSSText.Command = 'Redirect IEEELineCodes.DSS'
DSSText.Command = 'Redirect Lines_ieee123.txt'
DSSText.Command = 'Redirect Lines_ieee123SW.txt'
DSSText.Command = 'New Transformer.XFM1 Phases=3 Windings=2 Xhl=2.72 wdg=1 bus=61s conn=Delta kv=4.16 kva=150 %r=0.635 wdg=2 bus=610 conn=Delta kv=0.48 kva=150 %r=0.635'
DSSText.Command = 'Redirect IEEE123Regulators.DSS'
DSSText.Command = 'Redirect IEEE123Loads.DSS'

DSSText.Command = 'New Capacitor.C83       Bus1=83      Phases=3     kVAR=600     kV=4.16'
DSSText.Command = 'New Capacitor.C88a      Bus1=88.1    Phases=1     kVAR=50      kV=2.402'
DSSText.Command = 'New Capacitor.C90b      Bus1=90.2    Phases=1     kVAR=50      kV=2.402'
DSSText.Command = 'New Capacitor.C92c      Bus1=92.3    Phases=1     kVAR=50      kV=2.402'
DSSText.Command = 'New monitor.reg1a Transformer.reg1a 1 mode=1 ppolar=no'
DSSText.Command = 'New energymeter.reg1a element=Transformer.reg1a term= 1'
DSSText.Command = 'Set VoltageBases = [4.16, 0.48]'  #calcular voltajes en pu
DSSText.Command = 'calcv'
DSSText.Command = 'solve mode = snap'

DSSObj.ActiveCircuit.Solution.Solve()  #
Data_Customers['all_node_names']=opendss.DSSCircuit.AllNodeNames
Data_Customers['all_bus_names']=opendss.DSSCircuit.AllBusNames
Data_Customers['all_node_distances']=opendss.DSSCircuit.AllNodeDistances
Data_Customers['all_bus_distances']=opendss.DSSCircuit.AllBusDistances
Data_Customers['PVS_n']=pd.read_csv("IEEE123Loads.DSS",header=None, sep=' ') 
#Data_Customers['PVS_n2']=pd.read_csv("IEEE123Loads.DSS",header=None, sep='Load.')
Data_Customers['PVS_n2']=pd.DataFrame(pd.read_csv("IEEE123Loads.DSS",header=None, sep='Load.',engine='python'))
Data_Customers['PVS_n2'][1]=Data_Customers['PVS_n2'][1].str.split(' ',expand=True)

Data_Customers['Lines_n']=pd.read_csv("Lines_ieee123.txt",header=None, sep=' ')
Data_Customers['Lines_n_SW']=pd.read_csv("Lines_ieee123SW.txt",header=None, sep=' ')
#%%

exec(open(mydir +'/'+'Buses_Nodes.py').read())
exec(open(mydir +'/'+'Class_nodes_users.py').read())

for i in range(Data_Impact['MonteCarlo_Iterations']):
    x_seed.append(random.randrange(1,Data_Impact['MonteCarlo_Iterations']*1000))   

print(x_seed)
#%%    
#

MC_simulations=[]
Hierarchical_min=[]
average_vri=[]


for iMC in range(Data_Impact['MonteCarlo_Iterations']):
    DSSText = DSSObj.Text                                                          #   Set up the Text
    DSSText.Command = 'set DefaultBaseFrequency=60'
    DSSText.Command = 'clear'   
    DSSCircuit = DSSObj.ActiveCircuit                                              #   Set up the Circuit
    DSSSolution = DSSCircuit.Solution                                              #   Set up the Solution
    ControlQueue = DSSCircuit.CtrlQueue                                            #   Set up the Control
    DSSObj.AllowForms = 0 
#    
#    ###############################################################################
#    #  Llamar a los archivos txt
    DSSText.Command = 'New circuit.ieee123 basekv=4.16 Bus1=150 pu=1.00 R1=0 X1=0.0001 R0=0 X0=0.0001'
    DSSText.Command = 'new transformer.reg1a phases=3 windings=2 buses=[150 150r] conns=[wye wye] kvs=[4.16 4.16] kvas=[5000 5000] XHL=.001 %LoadLoss=0.00001 ppm=0.0' #red primaria
    DSSText.Command = 'new regcontrol.creg1a transformer=reg1a winding=2 vreg=120 band=2 ptratio=20 ctprim=700 R=3 X=7.5'
    DSSText.Command = 'Redirect IEEELineCodes.DSS'
    DSSText.Command = 'Redirect Lines_ieee123.txt'
    DSSText.Command = 'Redirect Lines_ieee123SW.txt'
    DSSText.Command = 'New Transformer.XFM1 Phases=3 Windings=2 Xhl=2.72 wdg=1 bus=61s conn=Delta kv=4.16 kva=150 %r=0.635 wdg=2 bus=610 conn=Delta kv=0.48 kva=150 %r=0.635'
    DSSText.Command = 'Redirect IEEE123Regulators.DSS'
    
    DSSText.Command = 'New Capacitor.C83       Bus1=83      Phases=3     kVAR=600     kV=4.16'
    DSSText.Command = 'New Capacitor.C88a      Bus1=88.1    Phases=1     kVAR=50      kV=2.402'
    DSSText.Command = 'New Capacitor.C90b      Bus1=90.2    Phases=1     kVAR=50      kV=2.402'
    DSSText.Command = 'New Capacitor.C92c      Bus1=92.3    Phases=1     kVAR=50      kV=2.402'
    DSSText.Command = 'New monitor.reg1a Transformer.reg1a 1 mode=1 ppolar=no'
    DSSText.Command = 'new monitor.TapTR1 element=transformer.reg1a terminal=2 mode=2'
    DSSText.Command = 'New energymeter.reg1a element=Transformer.reg1a term= 1'

    DSSText.Command = 'Redirect LoadShapes-2-2.txt'
    DSSText.Command = 'Redirect LoadDailys-2.txt'
    
    exec(open(mydir +'/'+'Call_MC.py').read())
    exec(open(mydir +'/'+'Rating_BESS_UR.py').read())

    
elapsed_time = time.process_time() - t
print('Elapsed Time: '+str(elapsed_time)+ ' seg ||| '+str(elapsed_time/60)+ ' min')           

currentDT = datetime.datetime.now()
print (str(currentDT))


#%%       

print('Stochastic total simulations: '+str(np.sum(MC_simulations)))
exec(open("Generate_HC_report_UR.py").read())
exec(open("PrintReport_UR.py").read())
#%%

for i in range(len(Data_PV['PVquant_history'])):
    Data_PV['PV_average'] = []
    for ii in range(len(Data_PV['PVquant_history'][i])):    
        Data_PV['PV_average'].append(np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_history'][i][ii]))/len(Data_Customers['PVS_n']))
    Data_PV['PV_average_history'].append(Data_PV['PV_average'])
#    
exec(open("ReportTXT_UR.py").read())
exec(open("ordenarPVE.py").read())

    


