# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 11:45:57 2020

@author: lanal
"""
#namestr=str((Data_Customers['Lines_n'][1][0]))
#print((Data_Customers['Lines_n'][1][0]))
#opendss.DSSCircuit.SetActiveElement(namestr)
Data_PV['pv-load_kw'] = []
Data_PV['pv-rec_kw'] = []
#Data_PV['battery_SoC'] = []
Data_PV['battery_beta'] = []
Data_PV['battery_droop'] = []
Data_PV['pv_average'] = []
Data_PV['p_proposed'] = []
Data_PV['p_proposed_bess'] = []
Data_PV['battery_SoC2'] = []                

Data_PV['battery_SoC']=np.zeros(np.shape(Data_PV['Bb']))
DSSText.Command = 'Redirect LoadShapes-2.txt'
DSSText.Command = 'Redirect LoadDailys-2.txt'
#print(ie)
shape_calc=[]
for istorage in range(len(Data_PV['Bb'])):

#shape_calc_1=[]
#for istorage in range(74,75):
#for istorage in range(0,75):
#for istorage in range(28,29):
    

    
    
    
    opendss.DSSCircuit.Generators.name='PV'+str(Data_PV['baxe'][0][0][istorage])
    pvkw=opendss.DSSCircuit.Generators.kvarated            
    opendss.DSSCircuit.LoadShapes.name='pvshape_'+str(Data_PV['baxe'][0][0][istorage])
    pvkwmult=opendss.DSSCircuit.LoadShapes.Pmult[ie]*GenMult
    pvkwmultnoav=list(np.multiply(opendss.DSSCircuit.LoadShapes.Pmult,1))
    if ie == 0:
        pvkwmultnoav[ie]=pvkwmultnoav[ie]*1
#        pvkwmultav=list(np.multiply(opendss.DSSCircuit.LoadShapes.Pmult,1))
#        pvkwmultav[ie]=np.average(pvkwmultnoav[0:T])
        pvaverage=np.average(pvkwmultnoav[0:T])*pvkw
    if ie > 0 and ie >= 1 and ie <= (Data_Case['hours']+(-1*T-1)):
        pvkwmultnoav[ie]=pvkwmultnoav[ie]*1*GenMult
        pvkwmultnoav[ie-1]=pvkwmultnoav[ie-1]*1*Data_Meters_SE['FPa_GENM'][ie-1]
#        pvkwmultav=list(np.multiply(opendss.DSSCircuit.LoadShapes.Pmult,1))
#        pvkwmultav[ie]=np.average(pvkwmultnoav[ie-1:ie+T])
        pvaverage=np.average(pvkwmultnoav[ie-1:ie+T])*pvkw
    Data_PV['pv_average'].append(pvaverage)
    
    opendss.DSSCircuit.Loads.name=Data_Customers['PVS_n2'][1][Data_PV['baxe'][0][0][istorage]].lower()
    loadkw=opendss.DSSCircuit.Loads.kW
    opendss.DSSCircuit.LoadShapes.name='loadshape_'+Data_Customers['PVS_n2'][1][Data_PV['baxe'][0][0][istorage]].lower()    
    loadkwmult=opendss.DSSCircuit.LoadShapes.Pmult[ie]*LoadMult
    kwpvout=pvkwmult*pvkw
    
    
    kwploadin=loadkwmult*loadkw
    kwneto=kwploadin-kwpvout
    Data_PV['pv-load_kw'].append(kwneto)                                                                                    
#    print(opendss.DSSCircuit.LoadShapes.name,loadkwmult)
    opendss.DSSCircuit.SetActiveElement('storage.batterypv'+str(Data_PV['baxe'][0][0][istorage]))
    SoCkwh=float(opendss.DSSCircuit.ActiveCktElement.Properties('kwhstored').val)
    SoC=float(opendss.DSSCircuit.ActiveCktElement.Properties('%stored').val)
    kWhba=float(opendss.DSSCircuit.ActiveCktElement.Properties('kwhrated').val)
    if ie == 0:
        kwrated=float(opendss.DSSCircuit.ActiveCktElement.Properties('kwrated').val)
        kwout=abs(float(opendss.DSSCircuit.ActiveCktElement.Properties('kw').val))
        SoCkwhini=float(opendss.DSSCircuit.ActiveCktElement.Properties('kwhstored').val)
    Data_PV['battery_SoC'][istorage]=SoC
    kwrated=battery_kwrated[istorage]
    
    opendss.DSSCircuit.LoadShapes.name='Storage_Shape'#+str(Data_PV['baxe'][0][0][istorage])
    beta_battery=list(opendss.DSSCircuit.LoadShapes.Pmult)
    
    if ie == 0:
        opendss.DSSCircuit.SetActiveElement('storage.batterypv'+str(Data_PV['baxe'][0][0][istorage]))
        SoCin = float(opendss.DSSCircuit.ActiveCktElement.Properties('%stored').val)
        beta_c=beta_battery[ie]
        SoCbess=SoCin
        
    elif ie <= (Data_Case['hours']-1) and ie >0:
#        SoC2=SoCbess2
#        Data_PV['battery_save_state'][istorage]=SoC
        
        SoC2=Data_PV['battery_save_state'][istorage]
        
#        print(SoC2)
#        SoC2=Data_PV['battery_SoC'][istorage]
        ProposedBESS=Data_PV['battery_save_bess'][istorage]
        SoCbess=(((ProposedBESS*5/60)+(SoC2*kWhba/100))/kWhba)*100
        
        if SoCbess >= Data_Case['Battery_maxSoC']:
            beta_battery[ie]=-1
            beta_c=beta_battery[ie]
        if Data_Case['Battery_refSoC'] < SoCbess and SoCbess < Data_Case['Battery_maxSoC']:
            beta_battery[ie]=-1
            beta_c=beta_battery[ie]
        if SoCbess == Data_Case['Battery_refSoC']:
            beta_battery[ie]=-1
            beta_c=beta_battery[ie]
        if Data_Case['Battery_minSoC'] < SoCbess and SoCbess < Data_Case['Battery_refSoC']:
            if kwpvout > 0:
                beta_battery[ie]=1
            elif kwpvout == 0 and Data_Case['Battery_minresSoC'] < SoCbess :
                beta_battery[ie]=-1
#            beta_battery[ie]=1
            beta_c=beta_battery[ie]
        if SoCbess <= Data_Case['Battery_minSoC']:
            beta_battery[ie]=1 
            beta_c=beta_battery[ie]

            
    
    opendss.DSSCircuit.LoadShapes.name='Storage_Shape'#+str(Data_PV['baxe'][0][0][istorage])
    opendss.DSSCircuit.LoadShapes.Pmult=tuple(beta_battery)   
#    opendss.DSSCircuit.LoadShapes.Pmult[ie]=beta_c
    beta=opendss.DSSCircuit.LoadShapes.Pmult[ie]
    beta=beta_c
    beta_battery=list(opendss.DSSCircuit.LoadShapes.Pmult)
    beta_ini[istorage]=beta
    
    if kwneto >= 0 and beta_ini[istorage] < 0:                
        if beta_ini[istorage] < 0 and abs(kwneto) >= kwrated:                    
            prec=kwrated
        if beta_ini[istorage] < 0 and abs(kwneto) < kwrated:
           prec=abs(kwneto)
    elif kwneto < 0 and beta_ini[istorage] > 0:
        if beta_ini[istorage] > 0 and abs(kwneto) >= kwrated:                    
            prec=kwrated
        if beta_ini[istorage] > 0 and abs(kwneto) < kwrated:
           prec=abs(kwneto)
    else:
        prec=0
    Data_PV['pv-rec_kw'].append(prec)
    

        
    Pdroop=-1*prec*beta_ini[istorage]
    Pproposed=Pdroop+pvaverage
    ProposedBESS=kwpvout-Pproposed



    shape_calc.append(-1*ProposedBESS/kwrated/1*beta)
#    shape_calc_1.append(shape_calc)
    
    opendss.DSSCircuit.SetActiveElement('storage.batterypv'+str(Data_PV['baxe'][0][0][istorage])) 
    opendss.DSSCircuit.ActiveElement.Properties('%effcharge').val=str(100)
    opendss.DSSCircuit.ActiveElement.Properties('%effdischarge').val=str(100)
    opendss.DSSCircuit.ActiveElement.Properties('%charge').val=str(100)
    opendss.DSSCircuit.ActiveElement.Properties('%discharge').val=str(100)
    opendss.DSSCircuit.ActiveElement.Properties('%idlingkw').val=str(0.01)
    opendss.DSSCircuit.ActiveElement.Properties('%idlingkw').val=str(0.01)
    if ProposedBESS < 0:
        opendss.DSSCircuit.ActiveElement.Properties('state').val='discharging'
        opendss.DSSCircuit.ActiveElement.Properties('kwrated').val=str((-1*ProposedBESS/1))
    if ProposedBESS > 0:
        opendss.DSSCircuit.ActiveElement.Properties('state').val='charging'
        opendss.DSSCircuit.ActiveElement.Properties('kwrated').val=str((-1*ProposedBESS/1))
    if ProposedBESS == 0:
        opendss.DSSCircuit.ActiveElement.Properties('kwrated').val=str((1*ProposedBESS))   
        opendss.DSSCircuit.ActiveElement.Properties('state').val='idling'
    
    else:
        opendss.DSSCircuit.ActiveElement.Properties('kwrated').val=str((-1*ProposedBESS/1))

    opendss.DSSCircuit.LoadShapes.name='Storage_Shape'+str(Data_PV['baxe'][0][0][istorage])
    shape_battery=list(opendss.DSSCircuit.LoadShapes.Pmult)
    shape_battery[ie]=1
    opendss.DSSCircuit.LoadShapes.Pmult=tuple(shape_battery)
    
#    opendss.DSSCircuit.LoadShapes.name='Storage_Shape'+str(Data_PV['baxe'][0][0][istorage])
#    shape_battery=list(opendss.DSSCircuit.LoadShapes.Pmult)
#    shape_battery[ie]=-1*ProposedBESS/kwrated/1*beta
#    opendss.DSSCircuit.LoadShapes.Pmult=tuple(shape_battery)

    
    
    
#    opendss.DSSCircuit.SetActiveElement('storage.batterypv'+str(Data_PV['baxe'][0][0][istorage]))
#    print((opendss.DSSCircuit.ActiveElement.Properties('kw').val),SoC,SoCbess,istorage,ie)
        

    
    STATE_B = 0
    SoCbess2=SoCbess
    Data_PV['battery_save_state'][istorage]=SoCbess2
    Data_PV['battery_save_bess'][istorage]=ProposedBESS
    Data_PV['battery_SoC2'].append(SoCbess)    
    Data_PV['battery_droop'].append(Pdroop)
    Data_PV['battery_beta'].append(beta_c)
    Data_PV['p_proposed'].append(Pproposed)
    Data_PV['p_proposed_bess'].append(ProposedBESS)
#    Data_PV['battery_save_bess_1'].append(Data_PV['battery_save_bess'])
#    print(Data_PV['battery_save_state'])
#Data_PV['battery_save_state_1'].append(Data_PV['battery_save_state'])
Data_PV['battery_SoC2_1'].append(Data_PV['battery_SoC2'])
Data_PV['p_proposed_1'].append(Data_PV['p_proposed'])        
Data_PV['p_proposed_bess_1'].append(Data_PV['p_proposed_bess'])
Data_PV['pv_average_1'].append(Data_PV['pv_average'])
Data_PV['battery_droop_1'].append(Data_PV['battery_droop'])    
Data_PV['battery_beta_1'].append(Data_PV['battery_beta'])            
Data_PV['battery_SoC_1'].append(Data_PV['battery_SoC'])
Data_PV['pv-rec_kw_1'].append(Data_PV['pv-rec_kw'])           
Data_PV['pv-load_kw_1'].append(Data_PV['pv-load_kw'])
shape_calc_1.append(shape_calc)

