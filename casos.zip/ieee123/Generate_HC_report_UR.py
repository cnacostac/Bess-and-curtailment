# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 14:35:43 2021

@author: lanal
"""

#%% Generate report

HCmin=[]
emptylist=[[]]*len(Data_HC['HC_perstd_max_history'])
if (Data_HC['HC_perstd_max_history']) == emptylist:
    Data_HC['HC_voltage_Impact']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No voltage impact with % of customers with voltage issues'],\
                                  ])  

else: 
    while([] in Data_HC['HC_perstd_max_history']) : 
        Data_HC['HC_perstd_max_history'].remove([]) 
        
    min_hc=[]
    for i in range(len(Data_HC['HC_perstd_max_history'])):
        min_hc.append([Data_HC['HC_perstd_max_history'][i][0][0],i,Data_HC['HC_perstd_max_history'][i][0][9]])

    HC_V=  (Data_HC['HC_perstd_max_history'][min(min_hc)[1]])
    Data_HC['HC_voltage_Impact']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['% GD Penetration (CAP. SE MAX 80%)', ((HC_V[0][4]/1000)*100)/Data_Case['SE_CAP']],\
                                  ['Total GD installed in kW', HC_V[0][4]],\
                                  ['Customers with PV', HC_V[0][2]],\
                                  ['GD average per customer in kW', HC_V[0][3]],\
                                  ['Maximum Voltage (pu)', HC_V[0][1]],\
                                  ['Minimum Voltage (pu)', HC_V[0][14]],\
                                  ['MC Case', HC_V[0][9]],\
                                  ['% GD Penetration (NUM. CURSTOMERS)', HC_V[0][0]],\
                                  ['Index Time Issue', HC_V[0][13]],\
                                  ['Time Issue Hours', str(int(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60))+\
                                   ':'+str("{:02d}".format(int(round((abs(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60)\
                                           -abs(int(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60)))*60,0))))],\
                                  ['Maximum % customer with issues', HC_V[0][6]],\
                                  ['Index Customer Issue', HC_V[0][7]],\
                                  ['Node Name Customer Issue', Data_Customers['all_node_names'][HC_V[0][7]]],\
                                  ['Customer Distance from Substation in km' , HC_V[0][8]],\
                                  ['Max Feeder Utilization %', HC_V[0][11]],\
                                  ['Energy MWh', HC_V[0][-4]],\
                                  ])  
    HCmin.append([HC_V[0][2],HC_V[0][9],HC_V[0][0],HC_V[0][-1]])


emptylist=[[]]*len(Data_HC['HC_perstd_max_history_min'])
if (Data_HC['HC_perstd_max_history_min']) == emptylist:
    Data_HC['HC_voltage_Impact_min']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No voltage impact with % of customers with voltage issues'],\
                                  ])  

else: 
    
    while([] in Data_HC['HC_perstd_max_history_min']) : 
        Data_HC['HC_perstd_max_history_min'].remove([])
        
    min_hc=[]
    for i in range(len(Data_HC['HC_perstd_max_history_min'])):
        min_hc.append([Data_HC['HC_perstd_max_history_min'][i][0][0],i,Data_HC['HC_perstd_max_history_min'][i][0][9]])

    HC_V=  (Data_HC['HC_perstd_max_history_min'][min(min_hc)[1]])
    Data_HC['HC_voltage_Impact_min']=dict([\
                                      ['Circuito', case_name],\
                                      ['Total Customers', len(Data_Customers['PVS_n'])],\
                                      ['% GD Penetration (CAP. SE MAX 80%)', ((HC_V[0][4]/1000)*100)/Data_Case['SE_CAP']],\
                                      ['Total GD installed in kW', HC_V[0][4]],\
                                      ['Customers with PV', HC_V[0][2]],\
                                      ['GD average per customer in kW', HC_V[0][3]],\
                                      ['Maximum Voltage (pu)', HC_V[0][14]],\
                                      ['Minimum Voltage (pu)', HC_V[0][1]],\
                                      ['MC Case', HC_V[0][9]],\
                                      ['% GD Penetration (NUM. CURSTOMERS)', HC_V[0][0]],\
                                      ['Index Time Issue', HC_V[0][13]],\
                                      ['Time Issue Hours', str(int(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60))+\
                                       ':'+str("{:02d}".format(int(round((abs(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60)\
                                               -abs(int(HC_V[0][13]*Data_Case['Resolution_std-data'][0]/60)))*60,0))))],\
                                      ['Maximum % customer with issues', HC_V[0][6]],\
                                      ['Index Customer Issue', HC_V[0][7]],\
                                      ['Node Name Customer Issue', Data_Customers['all_node_names'][HC_V[0][7]]],\
                                      ['Customer Distance from Substation in km' , HC_V[0][8]],\
                                      ['Max Feeder Utilization %', HC_V[0][11]],\
                                      ['Energy MWh', HC_V[0][-4]],\
                                      ])
    HCmin.append([HC_V[0][2],HC_V[0][10],HC_V[0][0],HC_V[0][-1]])


emptylist=[[]]*len(Data_HC['HC_perstd_max_history_UR'])
if (Data_HC['HC_perstd_max_history_UR']) == emptylist:
    Data_HC['HC_voltage_Impact_UR']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No voltage impact with % of customers with voltage issues'],\
                                  ])  

else: 
    
    while([] in Data_HC['HC_perstd_max_history_UR']) : 
        Data_HC['HC_perstd_max_history_UR'].remove([])
        
    min_hc=[]
    for i in range(len(Data_HC['HC_perstd_max_history_UR'])):
        min_hc.append([Data_HC['HC_perstd_max_history_UR'][i][0][0],i,Data_HC['HC_perstd_max_history_UR'][i][0][10]])

    HC_V=  (Data_HC['HC_perstd_max_history_UR'][min(min_hc)[1]])
    Data_HC['HC_voltage_Impact_UR']=dict([\
                                      ['Circuito', case_name],\
                                      ['Total Customers', len(Data_Customers['PVS_n'])],\
                                      ['% GD Penetration (CAP. SE MAX 80%)', ((HC_V[0][4]/1000)*100)/Data_Case['SE_CAP']],\
                                      ['Total GD installed in kW', HC_V[0][4]],\
                                      ['Customers with PV', HC_V[0][2]],\
                                      ['GD average per customer in kW', HC_V[0][3]],\
                                      ['% Unbalance Ratio (MAX 2%)', HC_V[0][6]],\
                                      ['Maximum Voltage (pu)', HC_V[0][12]],\
                                      ['Minimum Voltage (pu)', HC_V[0][13]],\
                                      ['MC Case', HC_V[0][10]],\
                                      ['% GD Penetration (NUM. CURSTOMERS)', HC_V[0][0]],\
                                      ['Node Name Customer Issue', HC_V[0][9]],\
                                      ['Customer Distance from Substation in km', HC_V[0][8]],\
                                      ['Max Feeder Utilization %', HC_V[0][14]],\
                                      ['Energy MWh', HC_V[0][-2]],\
                                      ])
    HCmin.append([HC_V[0][2],HC_V[0][9],HC_V[0][0],HC_V[0][-1]])


CurrentFlag_report=min(CurrentFlag_hist)


if min(CurrentFlag_hist) == [] and max(CurrentFlag_hist) == []:
    Data_HC['Current_Flags']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No current issues over 80% ES capacity'],\
                                  ]) 
else:
    while([] in CurrentFlag_hist) : 
        CurrentFlag_hist.remove([])
    CurrentFlag_report=min(CurrentFlag_hist)
    
    Data_HC['Current_Flags']=dict([\
                              ['Circuito', case_name],\
                              ['Total Customers', len(Data_Customers['PVS_n'])],\
                              ['% GD Penetration (CAP. SE MAX 80%)', (CurrentFlag_report[5]*len(Data_Customers['PVS_n'])/1000)/Data_Case['SE_CAP']*100],\
                              ['Total GD installed in kW', CurrentFlag_report[5]*len(Data_Customers['PVS_n'])],\
                              ['Customers with PV', math.ceil(len(Data_Customers['PVS_n'])*CurrentFlag_report[0]/100)],\
                              ['GD average per customer in kW', CurrentFlag_report[5]],\
                              ['% GD penetration', CurrentFlag_report[0]],\
                              ['% Line Utilization '+ str(CurrentFlag_report[0]), CurrentFlag_report[1]],\
                              ['Maximum Voltage (pu)', CurrentFlag_report[6]],\
                              ['Minimum Voltage (pu)', CurrentFlag_report[7]],\
                              ['MC Case', CurrentFlag_report[2]],\
                              ['Index Time', CurrentFlag_report[3]],\
                              ['Time Issue Hours', str(int(CurrentFlag_report[3]*Data_Case['Resolution_std-data'][1]/60))+\
                               ':'+str("{:02d}".format(int(round((abs(CurrentFlag_report[3]*Data_Case['Resolution_std-data']\
                                       [1]/60)-abs(int(CurrentFlag_report[3]*Data_Case['Resolution_std-data'][1]/60)))*60))))],\
                              ['Index Section', CurrentFlag_report[4]],\
                              ['Feeder Name', lines_names[CurrentFlag_report[4]]],\
                              ['Feeder [Bus1,Bus2]', [opendss.DSSCircuit.SetActiveElement(str("line.")+\
                               str(lines_names[CurrentFlag_report[4]])),opendss.DSSCircuit.ActiveCktElement.BusNames]],\
                              ['Total Number of Customer Served', [opendss.DSSCircuit.Lines.TotalCust,\
                                                                   str(int(round(np.multiply(opendss.DSSCircuit.Lines.TotalCust/\
                                                                       len(Data_Customers['PVS_n']),100))))+str("%")]],\
                              ['Number of Customers on this Line Section', opendss.DSSCircuit.Lines.NumCust],\
                              ['Max Feeder Utilization %', CurrentFlag_report[8]],\
                              ['-1 Feeder Utilization %', CurrentFlag_report[9]],\
                              ['Energy MWh', CurrentFlag_report[-2]],\
                              ])                                                                    
    HCmin.append([math.ceil(len(Data_Customers['PVS_n'])*CurrentFlag_report[0]/100),CurrentFlag_report[2],CurrentFlag_report[0],CurrentFlag_report[-1]])



VoltageFlagmax_report=min(VoltageFlagmax_hist)

if VoltageFlagmax_report == []:
    Data_HC['Voltage_Flags_Sup']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No voltage issues'],\
                                  ])  
else:
    Data_HC['Voltage_Flags_Sup']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['% GD Penetration (CAP. SE MAX 80%)',(VoltageFlagmax_report[5]*len(Data_Customers['PVS_n'])/1000)/Data_Case['SE_CAP']*100],\
                                  ['Total GD installed in kW', VoltageFlagmax_report[5]*len(Data_Customers['PVS_n'])],\
                                  ['Customers with PV', math.ceil(len(Data_Customers['PVS_n'])*VoltageFlagmax_report[0]/100)],\
                                  ['% GD penetration', VoltageFlagmax_report[0]],\
                                  ['GD average per customer in kW', VoltageFlagmax_report[5]],\
                                  ['Voltage Issue (pu)', VoltageFlagmax_report[1]],\
                                  ['Index Node', VoltageFlagmax_report[4]],\
                                  ['Node Name', Data_Customers['all_node_names'][VoltageFlagmax_report[4]]],\
                                  ['Node Distance from Substation in km', Data_Customers['all_node_distances']\
                                   [VoltageFlagmax_report[4]]],\
                                  ['MC Case', VoltageFlagmax_report[2]],\
                                  ['Index Time', VoltageFlagmax_report[3]],\
                                  ['Time Issue Hours', str(int(VoltageFlagmax_report[3]*Data_Case['Resolution_std-data'][1]/60))\
                                   +':'+str("{:02d}".format(int(round((abs(VoltageFlagmax_report[3]\
                                            *Data_Case['Resolution_std-data'][1]/60)-abs(int(VoltageFlagmax_report[3]\
                                                      *Data_Case['Resolution_std-data'][1]/60)))*60))))],\
                                  ['Max Feeder Utilization %', VoltageFlagmax_report[8]],\
                                  ['Energy MWh', VoltageFlagmax_report[-2]],\
                                  ])

VoltageFlagmin_report=min(VoltageFlagmin_hist)
if VoltageFlagmin_report == []:
    Data_HC['Voltage_Flags_Min']=dict([\
                                  ['Circuito', case_name],\
                                  ['Total Customers', len(Data_Customers['PVS_n'])],\
                                  ['Limit', 'No voltage issues'],\
                                  ]) 
else:                                      
    Data_HC['Voltage_Flags_Min']=dict([\
                              ['Circuito', case_name],\
                              ['Total Customers', len(Data_Customers['PVS_n'])],\
                              ['% GD Penetration (CAP. SE MAX 80%)',(VoltageFlagmin_report[5]*len(Data_Customers['PVS_n'])/1000)/Data_Case['SE_CAP']*100],\
                              ['Total GD installed in kW', VoltageFlagmin_report[5]*len(Data_Customers['PVS_n'])],\
                              ['Customers with PV', math.ceil(len(Data_Customers['PVS_n'])*VoltageFlagmin_report[0]/100)],\
                              ['% GD penetration', VoltageFlagmin_report[0]],\
                              ['GD average per customer in kW', VoltageFlagmin_report[5]],\
                              ['Voltage Issue (pu)', VoltageFlagmin_report[1]],\
                              ['Index Node', VoltageFlagmin_report[4]],\
                              ['Node Name', Data_Customers['all_node_names'][VoltageFlagmin_report[4]]],\
                              ['Node Distance from Substation in km', Data_Customers['all_node_distances']\
                               [VoltageFlagmin_report[4]]],\
                              ['MC Case', VoltageFlagmin_report[2]],\
                              ['Index Time', VoltageFlagmin_report[3]],\
                              ['Time Issue Hours', str(int(VoltageFlagmin_report[3]*Data_Case['Resolution_std-data'][1]/60))\
                               +':'+str("{:02d}".format(int(round((abs(VoltageFlagmin_report[3]\
                                        *Data_Case['Resolution_std-data'][1]/60)-abs(int(VoltageFlagmin_report[3]\
                                                  *Data_Case['Resolution_std-data'][1]/60)))*60))))],\
                              ['Max Feeder Utilization %', VoltageFlagmin_report[8]],\
                              ['Energy MWh', VoltageFlagmax_report[-2]],\
                              ])