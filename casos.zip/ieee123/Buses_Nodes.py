# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 16:59:17 2021

@author: lanal
"""

if Data_Case['Buses(0)_Nodes(1)'] == [0]: #buses
    for ie in range(0,1):
        for i in range(len(Data_Customers['all_bus_names'])):
            for ii in range(len(Data_Customers['PVS_n'])):
                if ('Bus1='+str(Data_Customers['all_bus_names'][i])) == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.1') == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.2') == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.3') == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.1.2') == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.2.3') == str(Data_Customers['PVS_n'][2][ii])\
                or ('Bus1='+str(Data_Customers['all_bus_names'][i])+'.3.1') == str(Data_Customers['PVS_n'][2][ii]):
                    Data_Customers['NodeNames_BusV'].append(i)   
    for i in range(len(Data_Customers['NodeNames_BusV'])):
        Data_Customers['NodeNames_Locations'].append(Data_Customers['all_bus_distances'][Data_Customers['NodeNames_BusV'][i]])                  
elif Data_Case['Buses(0)_Nodes(1)'] == [1]: #nodos
    for ie in range(0,1):
        for i in range(len(Data_Customers['all_node_names'])):
            for ii in range(len(Data_Customers['PVS_n'])):
                if ('Bus1='+str(Data_Customers['all_node_names'][i])) == str(Data_Customers['PVS_n'][2][ii]):
                    Data_Customers['NodeNames_BusV'].append(i)
        for i in range(len(Data_Customers['all_bus_names'])):
                for ii in range(len(Data_Customers['PVS_n'])):
                    if ('Bus1='+str(Data_Customers['all_bus_names'][i])) == str(Data_Customers['PVS_n'][2][ii]):
                        Data_Customers['NodeNames_BusV'].append(i)
    for i in range(len(Data_Customers['NodeNames_BusV'])):
        Data_Customers['NodeNames_Locations'].append(Data_Customers['all_node_distances'][Data_Customers['NodeNames_BusV'][i]])
voltages=[opendss.DSSCircuit.AllBusNames,opendss.DSSCircuit.AllBusVmagPu]
seed(1)
sequence = [i for i in range(len(Data_Customers['PVS_n']))]