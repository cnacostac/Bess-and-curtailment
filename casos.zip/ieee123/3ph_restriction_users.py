# -*- coding: utf-8 -*-
"""
Created on Mon May 10 14:14:54 2021

@author: lanal
"""

#check 3ph nodes
#ph_buses=sample(Nodes33, math.ceil(len(Nodes33)*Data_Impact['PerPen'][iep]/100))
ph_buses=Nodes332.copy()
array_okey=[]
arry_not=[]
#node_pv=Data_Customers['PVS_n'][2:3]
#node_pv_ph=Data_Customers['PVS_n'][3]
#node_pv_bus=Data_Customers['PVS_n'][2]
for i in range(len(Data_PV['baxe'][0][0])):
    if Data_PV['baxe'][0][1][i] >= Data_Case['PV_minH'] and  node_names[1][Data_PV['baxe'][0][0][i]] in Nodes_33ph:
#        array_okey.append('okey '+str(i)+' '+str(node_names[1][Data_PV['baxe'][0][0][i]])+' '+str(Data_PV['baxe'][0][0][i]))
        array_okey.append(Data_PV['baxe'][0][0][i])
#        node_pv_ph[Data_PV['baxe'][0][0][i]]=phases_pv[Data_PV['baxe'][0][0][i]]
#        node_pv_bus[Data_PV['baxe'][0][0][i]]=Nodes_pvs[Data_PV['baxe'][0][0][i]]
#        Nodes_pvs[Data_PV['baxe'][0][0][i]]
    elif Data_PV['baxe'][0][1][i] >= Data_Case['PV_minH'] and (node_names[1][Data_PV['baxe'][0][0][i]] in Nodes_11ph or node_names[1][Data_PV['baxe'][0][0][i]] in Nodes_22ph):
#        arry_not.append('No okey '+str(i)+' '+str(node_names[1][Data_PV['baxe'][0][0][i]])+' '+str(Data_PV['baxe'][0][0][i]))
        arry_not.append(i)


for i in range(len(array_okey)):
    ph_buses.remove(array_okey[i])
#
random_choices=random.choices(ph_buses, k=len(arry_not))
for i in range(len(arry_not)):
#    print(Data_PV['baxe'][0][0][arry_not[i]],random_choices[i])
    Data_PV['baxe'][0][0][arry_not[i]]=random_choices[i]
#    node_pv_ph[Data_PV['baxe'][0][0][arry_not[i]]]=phases_pv[Data_PV['baxe'][0][0][arry_not[i]]]
    
#array_okey_b=[]
#arry_not_b=[]
#for i in range(len(Data_PV['baxe_battery'][0][0])):
#    if Data_PV['baxe_battery'][0][0][i] >= Data_Case['PV_minH'] and  Data_PV['baxe'][0][0][i] in ph_buses:
#        array_okey_b.append('okey '+str(i)+' '+str(Data_Customers['all_bus_names'][Data_PV['baxe'][0][0][i]]))
#    elif Data_PV['baxe_battery'][0][0][i] >= Data_Case['PV_minH'] and (Data_PV['baxe'][0][0][i] in Nodes_1ph_customer or Data_PV['baxe'][0][0][i] in Nodes_2ph_customer):
#        arry_not_b.append(i)

#random_choices=random.choices(ph_buses, k=len(arry_not_b))
#rnd_bat=Data_PV['baxe_battery']
#for i in range(len(arry_not)):
#    Data_PV['baxe_battery'][0][0][arry_not_b[i]]=random_choices[i]