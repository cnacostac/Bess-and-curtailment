# -*- coding: utf-8 -*-
"""
Created on Mon May 10 13:22:40 2021

@author: lanal
"""

#clasificar nodos
Nodes_11ph=[]
Nodes_22ph=[]
Nodes_33ph=[]
Nodes33=[]
Node=[]
Nodes_pvs=[]
phases_pv=[]
phases1=[]
#Nodes_1ph_customer=[]
#Nodes_2ph_customer=[]
#Nodes_3ph_customer=[]
node_names=pd.read_csv("IEEE123Loads.DSS",header=None, sep=' ') 
node_names=node_names[2].str.split('=',expand=True)
#node_pv=Data_Customers['PVS_n']
for ibus  in range(len(node_names[0])):
    opendss.DSSCircuit.SetActiveBus(str(node_names[1][ibus]))

    if opendss.DSSCircuit.ActiveBus.NumNodes == 1:
        Nodes_11ph.append(str(node_names[1][ibus]))
        Node='Bus1='+str(node_names[1][ibus])
        phases1='Phases=1'
#        Nodes_11ph.append([node_names[1][ibus],opendss.DSSCircuit.ActiveBus.name,ibus])
    if opendss.DSSCircuit.ActiveBus.NumNodes == 2:
#        Nodes_22ph.append([node_names[1][ibus],opendss.DSSCircuit.ActiveBus.name,ibus])
        Nodes_22ph.append(str(node_names[1][ibus]))
        Node='Bus1='+str(node_names[1][ibus])
        phases1='Phases=2'
    if opendss.DSSCircuit.ActiveBus.NumNodes == 3:
#        Nodes_33ph.append([node_names[1][ibus],opendss.DSSCircuit.ActiveBus.name,ibus])
#        Nodes_33ph.append(str(opendss.DSSCircuit.ActiveBus.name))
        Nodes_33ph.append(str(node_names[1][ibus]))
        Nodes33.append(ibus)
        Node='Bus1='+str(opendss.DSSCircuit.ActiveBus.name)
        phases1='Phases=3'
    Nodes_pvs.append(Node)
    phases_pv.append(phases1)
Nodes332=Nodes33.copy()

#for ibus  in range(len(Data_Customers['NodeNames_BusV'])):
#    opendss.DSSCircuit.SetActiveBus(str(Data_Customers['all_bus_names'][Data_Customers['NodeNames_BusV'][ibus]]))
#
#    if opendss.DSSCircuit.ActiveBus.NumNodes == 1:
#        Nodes_1ph_customer.append(ibus)
#    if opendss.DSSCircuit.ActiveBus.NumNodes == 2:
#        Nodes_2ph_customer.append(ibus)
#    if opendss.DSSCircuit.ActiveBus.NumNodes == 3:
#        Nodes_3ph_customer.append(ibus)    
    