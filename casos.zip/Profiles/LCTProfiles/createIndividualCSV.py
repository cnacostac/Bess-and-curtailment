# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 16:20:34 2019

@author: lanal
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#file = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\Combined_Load_Profiles.xlsx'
#cmd = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\\LoadProfiles3'
#profiles = pd.read_excel(file, header=None, index=None)
#
#
#for iprof in range(400):
#    profiles[iprof].to_csv(cmd + "\\profile_" + str(iprof) + ".csv", index=None)
#
#
#
#file = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\\LoadProfiles3'
#cmd = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\Norm_Load_Prof'
###NormPVS=(np.array(PVShape_n)-min(PVShape_n))/(max(PVShape_n)-min(PVShape_n))
##
#for iprof in range(400):
#    profilesL = pd.read_csv(file + "\\profile_" + str(iprof) + ".csv")
#    profilesL = np.array(profilesL)
#    profilesL = (np.array(profilesL)-min(profilesL))/(max(profilesL)-min(profilesL))
#    profilesL = pd.DataFrame(data=profilesL)
#    profilesL.to_csv(cmd + "\\Nprofile_" + str(iprof) + ".csv", index=None) #esto crea los perfiles por separado
    
    
    
fileL = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\Norm_Load_Prof'
filePV = 'C:\\Users\\lanal\\OneDrive\\OpenDSSProjects\\TecNM\\JARDINESTOREO\\Profiles\\LCTProfiles\\Norm_PV_Prof'
##NormPVS=(np.array(PVShape_n)-min(PVShape_n))/(max(PVShape_n)-min(PVShape_n))
#
plt.figure(111)
for iprof in range(113,114):
    profilesL = pd.read_csv(fileL + "\\Nprofile_" + str(iprof) + ".csv")
    profilesL = np.array(profilesL)
    plt.plot(profilesL)
plt.title('Normalized Customers Profiles')
plt.xlim([0, 287])

plt.figure(112)
for iprof in range(113,114):
    profilesPV = pd.read_csv(filePV + "\\Nprofile_" + str(iprof) + ".csv")
    profilesPV = np.array(profilesPV)
    plt.plot(profilesPV)    
plt.title('Normalized PV Profiles')
plt.xlim([0, 287])
