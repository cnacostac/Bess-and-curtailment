# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 11:26:15 2020

@author: lanal
"""
Vne=[]
V1=opendss.DSSCircuit.AllNodeVmagPUByPhase(1)
V2=opendss.DSSCircuit.AllNodeVmagPUByPhase(2)
V3=opendss.DSSCircuit.AllNodeVmagPUByPhase(3)
V3phav=np.add(V3,np.add(V1,V2))/3
Vmin3ph=[]
Vu3phmax=[]
for iph in range(len(V1)):
    Vmin3ph.append(min(V1[iph],V2[iph],V3[iph]))
Vu3ph=((V3phav-Vmin3ph)/V3phav)*100
#Vu3phmax=[np.max(Vu3ph),np.argmax(Vu3ph),ie,iep,iMC,]
#Vu3phmax.append([np.max(Vu3ph),np.argmax(Vu3ph),ie,iep,iMC])
Vne=Vu3ph
Vu3phmax.append(Vu3ph)