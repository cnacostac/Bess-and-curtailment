# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 21:44:25 2019

@author: Nallely Acosta TECNM/Instituto Tecnológico de Morelia
"""
import statistics
import matplotlib
import numpy as np
import numpy
import matplotlib.pyplot as plt #abrir figuras en ventanas
import math
import re
import pandas as pd
import random
from matplotlib import collections  as mc
import opendss_class as opendss
from random import seed
from random import choice
from random import sample
import matplotlib.cm as cm
import time
import os
import heapq
import datetime as dt
opendss = opendss.opendss()
import datetime
import matplotlib as mpl
import matplotlib as mpl


currentDT = datetime.datetime.now()
print (str(currentDT))
t = time.process_time()


mydir = 'C:/Users/Usersname/casos/Mfeeder'
Read_excel = 'C:\\Users\\Username\\casos\\Mfeeder\\'
PVprofiles = '(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Norm_PV_Prof\\Nprofile_'
Loadprofiles = '(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Norm_Load_Prof\\Nprofile_'


LoadMult=1
GenMult1=1
gencur_adj=0.0
gencur_adjup=0.0
gen_min=0.8

# 10 min T=1, 15 min T=2, 20 min T=3
T=1
ur_tol=1

vpu_tol=0.02
case_name='Case1_TAP_LM'+str(LoadMult)+'_FL'
#['PVSize_data', [1, 5, 10, 30, 50, 100, 500]],\
## Basic definitions
#30,20,20,1,1,1, 1, 13, 13      43,21,20,1,1,1, 1, 9, 5
# Tarifas 
# GDMTH	Gran Demanda en Media Tensión horaria	HM, HMC, 6   demanda >= 100 kW
# GDMTO	Gran Demanda en Media Tensión ordinaria	OM, 6        demanda >= 10 kW
# RAMT	Riego Agrícola en Media Tensión	9M



Data_Case=dict([\
                ['SE_CAP', 10.5],\
                ['hours', 288],\
                ['PVSize_data', np.divide([1, 5, 10, 30, 50,100,250,500],1)],\
                ['PerPVSize_data', np.divide([3,18,24,52,0,0,2,1],100)],\
                ['BatterySize_data', np.divide([4, 4, 8, 24, 36,48,132,252],1)],\
                ['BatteryMaxRate_data', np.divide([1.6, 1.6, 3.2, 9.6, 14.4,19.2,52.8,100.8],1)],\
                ['PV_minH', 50],\
                ['Vlimit_pu', [0.93, 1.05]],\
                ['UR_Maxim%', 2],\
                ['Resolution_std-data', [10, 5]],\
                ['%-Cumplimiento-Tension', 95],\
                ['OverCurrentLimit', np.divide(50,100)],\
                ['CurrentLimit_%', 80],\
                ['SubestationSLimit_%', np.divide(80,100)],\
                ['TransformerSLimit_%', np.divide(80,100)],\
                ['Buses(0)_Nodes(1)', [0]],\
                ['WiresData', []],\
                ['CableData', []],\
                ['Lines', []],\
                ['Geometries', []],\
                ['Loads', []],\
                ['Loads_Daily', []],\
                ['Large_Customers', []],\
                ['Large_Customers_Daily', []],\
                ['Load_Shapes', []],\
                ['PV_Shapes', []],\
                ['Battery_refSoC_ini',10],\
                ['Battery_refSoC', 90],\
                ['Battery_minSoC', 5],\
                ['Battery_minresSoC', 10],\
                ['Battery_maxSoC', 90],\
                ])

exec(open(mydir +'/'+'Read_Circuit_info.py').read())
exec(open(mydir +'/'+'Call_Dict2.py').read())


Data_PV['Baxe_battery_history']=[]
Data_Impact=dict([\
                ['Pmax', 100],\
                ['itera', 0],\
                ['Per_actual', 0],\
                ['PerPen', [60]],\
                ['MonteCarlo_Iterations',1],\
                ])

PV_sizes=[]
for i in range(len(Data_Case['PVSize_data'])):
    if Data_Case['PVSize_data'][i] >= Data_Case['PV_minH']:
        PV_sizes.append(Data_Case['PVSize_data'][i])
PV_sizes=PV_sizes[::-1]        


#%%
## ****************************************************************************
#                                        Initialize OpenDSS
# *****************************************************************************
import DSSStartup as dsss
DSSStartOK, DSSObj, DSSText = dsss.DSSStartup()
if not DSSStartOK:
    print('Unable to start the OpenDSS Engine')
    import sys
    sys.exit()

DSSText = DSSObj.Text                                                          #   Set up the Text
DSSText.Command = 'set DefaultBaseFrequency=60'
DSSText.Command = 'clear'   
#DSSText.Command = 'Compile '+mydir+'/'+'Case.dss'    #   In Python strings are concatenated with the operator "+" e.g. 'Hello,' + ' World!' = 'Hello, World!'
DSSCircuit = DSSObj.ActiveCircuit                                              #   Set up the Circuit
DSSSolution = DSSCircuit.Solution                                              #   Set up the Solution
ControlQueue = DSSCircuit.CtrlQueue                                            #   Set up the Control
DSSObj.AllowForms = 0 

###############################################################################
#  Llamar a los archivos txt
DSSText.Command = 'new circuit.example basekV=13.8 angle=0 frequency=60 phases=3' #   Clear text command
DSSText.Command = 'Edit Vsource.Source BasekV=13.8 pu=1.00 ISC3=3000 ISC1=2500 baseMVA=10'  #ISC3=3000  ISC1=2500'
DSSText.Command = 'New Transformer.TR1 Buses=[SourceBus, mrd04015] Conns=[delta, delta] kVs=[115, 13.8] kVAs=[20000, 10500] windings=2 phases=3' #red primaria

DSSText.Command = 'Redirect Wire_Data-2.txt'
DSSText.Command = 'Redirect Cable_Data-2.txt'
DSSText.Command = 'Redirect Geometry_Data-2.txt'
DSSText.Command = 'Redirect LargeCustomer_Data-2.txt'
DSSText.Command = 'Redirect Line_Data-2.txt'
DSSText.Command = 'Redirect Loads.txt'

DSSText.Command = 'New Capacitor.Cap_OH_135923 Bus1=nd_137372 phases=3 kvar=298 kV=13.8 states=1'
DSSText.Command = 'New monitor.SE Transformer.TR1 1 mode=1 ppolar=no'
DSSText.Command = 'New energymeter.TR1 element=Transformer.TR1 term= 1'
DSSText.Command = 'set voltagebases=[115,69,34.5,13.8,7.9674]'  #calcular voltajes en pu
DSSText.Command = 'calcv'
DSSText.Command = 'solve mode = snap'

DSSObj.ActiveCircuit.Solution.Solve()  #
#%%
Data_Customers['all_node_names']=opendss.DSSCircuit.AllNodeNames
Data_Customers['all_bus_names']=opendss.DSSCircuit.AllBusNames
Data_Customers['all_node_distances']=opendss.DSSCircuit.AllNodeDistances
Data_Customers['all_bus_distances']=opendss.DSSCircuit.AllBusDistances
Data_Customers['PVS_n']=pd.read_csv("Loads.txt",header=None, sep=' ') 
Data_Customers['PVS_n2']=pd.read_csv("Loads.txt",header=None, sep='.')
Data_Customers['PVS_n2']=pd.DataFrame(pd.read_csv("Loads.txt",header=None, sep='.'))
Data_Customers['PVS_n2'][1]=Data_Customers['PVS_n2'][1].str.split(' ',expand=True)

Data_Customers['Lines_n']=pd.read_csv("Line_Data-2.txt",header=None, sep=' ')
#%%

exec(open(mydir +'/'+'Buses_Nodes.py').read())
exec(open(mydir +'/'+'Class_nodes_users.py').read())


for i in range(Data_Impact['MonteCarlo_Iterations']):
    x_seed.append(random.randrange(1,Data_Impact['MonteCarlo_Iterations']*1000))   
print(x_seed)
#%%    
Vu3phmax_history=[]
bstate_history=[]
MC_simulations=[]
Hierarchical_min=[]
average_vri=[]

for iMC in range(Data_Impact['MonteCarlo_Iterations']):
    DSSText = DSSObj.Text                                                          #   Set up the Text
    DSSText.Command = 'set DefaultBaseFrequency=60'
    DSSText.Command = 'clear'   
    #DSSText.Command = 'Compile '+mydir+'/'+'Las_Americas-3.dss'    #   In Python strings are concatenated with the operator "+" e.g. 'Hello,' + ' World!' = 'Hello, World!'
    DSSCircuit = DSSObj.ActiveCircuit                                              #   Set up the Circuit
    DSSSolution = DSSCircuit.Solution                                              #   Set up the Solution
    ControlQueue = DSSCircuit.CtrlQueue                                            #   Set up the Control
    DSSObj.AllowForms = 0 
    
    ###############################################################################
    #  Llamar a los archivos txt
    DSSText.Command = 'new circuit.example basekV=13.8 angle=0 frequency=60 phases=3' #   Clear text command
    DSSText.Command = 'Edit Vsource.Source BasekV=13.8 pu=1.00 ISC3=3000 ISC1=2500 baseMVA=10'  #ISC3=3000  ISC1=2500'
    DSSText.Command = 'New Transformer.TR1 Buses=[SourceBus, mrd04015] Conns=[delta, delta] kVs=[115, 13.8] kVAs=[20000, 10500] windings=2 phases=3 maxtap=1.05 mintap=0.93' #red primaria
    DSSText.Command = 'new regcontrol.TapTR1 transformer=TR1 winding=2 tapwinding=2 vreg=(100) ptratio=80 band=2 maxtapchange=1.05'  #1
    DSSText.Command = 'Redirect Wire_Data-2.txt'
    DSSText.Command = 'Redirect Cable_Data-2.txt'
    DSSText.Command = 'Redirect Geometry_Data-2.txt'
    DSSText.Command = 'Redirect Line_Data-2.txt'
    DSSText.Command = 'Redirect LoadShapes-2.txt'
    DSSText.Command = 'Redirect LargeCustomer_Daily-2.txt'
    DSSText.Command = 'Redirect LoadDailys-3.txt'
    DSSText.Command = 'New Capacitor.Cap_OH_135923 Bus1=nd_137372 phases=3 kvar=298 kV=13.8 states=1'
    DSSText.Command = 'New monitor.SE Transformer.TR1 1 mode=1 ppolar=no'
    DSSText.Command = 'new monitor.TapTR1 element=transformer.TR1 terminal=2 mode=2'
    DSSText.Command = 'New energymeter.reg1a element=Transformer.TR1 term= 1'
    
    exec(open(mydir +'/'+'Call_MC.py').read())
    exec(open(mydir +'/'+'Rating_BESS_UR.py').read())

    
elapsed_time = time.process_time() - t
print('Elapsed Time: '+str(elapsed_time)+ ' seg ||| '+str(elapsed_time/60)+ ' min')           

currentDT = datetime.datetime.now()
print (str(currentDT))

#%%
print('Stochastic total simulations: '+str(np.sum(MC_simulations)))
exec(open("Generate_HC_report_UR.py").read())
exec(open("PrintReport_UR.py").read())
#%%
for i in range(len(Data_PV['PVquant_history'])):
    Data_PV['PV_average'] = []
    for ii in range(len(Data_PV['PVquant_history'][i])):    
        Data_PV['PV_average'].append(np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_history'][i][ii]))/len(Data_Customers['PVS_n']))
    Data_PV['PV_average_history'].append(Data_PV['PV_average'])

#print(Data_Impact['MonteCarlo_Iterations'],np.average(average_vri))

#%%
    
exec(open("PrintReport_UR.py").read())
###    
exec(open("ReportTXT_UR.py").read())
exec(open("ordenarPVE_UR.py").read())



