# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 14:01:32 2020

@author: Clarissa Acosta TECNM/Instituto Tecnológico de Morelia
"""

# Randomize
Data_Customers['Customers_quant'] = []
Data_Voltage['Voltage_Profile_all'] = []
Data_Voltage['VMax_mag_MC'] = []
Data_Voltage['VMax_mag_MC_loc'] = []
Data_Voltage['Vmax_bus'] = []
Data_Voltage['Vmax_bus_location'] = []
Data_Voltage['Vmin_bus'] = []
Data_Voltage['Vmin_bus_location'] = []
Data_Meters_SE['EM_se'] = []
Data_PV['PVquant_save'] = []
Data_PV['baxe_save'] = []
Data_PV['baxe_battery_save'] = []
Data_PV['Bb_loc'] = []
Data_PV['pv_list_all'] = []
Data_Current['Iut_maxim_save'] = []
Data_Current['Iut_mag_save'] = []
Data_Current['Iut_normamps_save'] = []
Data_Current['Iut_normampsMAX_save'] = []
Data_Current['I_customer_save'] = []
Data_Current['I_PV_amps_save'] = []
Data_Current['I_net_amps_save'] = []
Data_Meters_SE['Tap_change']= []
Data_Current['Line_Losses_wq_mc'] = []
Data_Meters_SE['FPa_GENM_all'] = []
Data_Meters_SE['EMeters'] = []
Data_PV['pv-load_kw_1']=[]
Data_PV['Bess_SoC']=[]
Vu3phmax_save = []
monitor_line=[]
Vu3phmax_max_save=[]

for iep in range(len(Data_Impact['PerPen'])):
#    print(iep)
    
    DSSText = DSSObj.Text                                                          #   Set up the Text
    DSSText.Command = 'set DefaultBaseFrequency=60'
    DSSText.Command = 'clear'
    DSSCircuit = DSSObj.ActiveCircuit                                              #   Set up the Circuit
    DSSSolution = DSSCircuit.Solution                                              #   Set up the Solution
    ControlQueue = DSSCircuit.CtrlQueue                                            #   Set up the Control
    DSSObj.AllowForms = 0 
   
    ###############################################################################
    #  Llamar a los archivos txt    
    DSSText.Command = 'new circuit.example basekV=13.8 angle=0 frequency=60 phases=3' #   Clear text command
    DSSText.Command = 'Edit Vsource.Source BasekV=13.8 pu=1.00 ISC3=3000 ISC1=2500 baseMVA=10'  #ISC3=3000  ISC1=2500'
    DSSText.Command = 'New Transformer.TR1 Buses=[SourceBus, mrd04015] Conns=[delta, delta] kVs=[115, 13.8] kVAs=[20000, 10500] windings=2 phases=3 maxtap=1.05 mintap=0.93' #red primaria
    DSSText.Command = 'new regcontrol.TapTR1 transformer=TR1 winding=2 tapwinding=2 vreg=(100) ptratio=80 band=2 maxtapchange=1.05'  #1 
    DSSText.Command = 'Redirect Wire_Data-2.txt'
    DSSText.Command = 'Redirect Cable_Data-2.txt'
    DSSText.Command = 'Redirect Geometry_Data-2.txt'
    DSSText.Command = 'Redirect Line_Data-2.txt'
    DSSText.Command = 'Redirect LoadShapes-2.txt'
    DSSText.Command = 'Redirect LargeCustomer_Daily-2.txt'
    DSSText.Command = 'Redirect LoadDailys-3.txt'
    DSSText.Command = 'New Capacitor.Cap_OH_135923 Bus1=nd_137372 phases=3 kvar=298 kV=13.8 states=1'
    DSSText.Command = 'New monitor.SE Transformer.TR1 1 mode=1 ppolar=no'
    DSSText.Command = 'new monitor.TapTR1 element=transformer.TR1 terminal=2 mode=2'
    DSSText.Command = 'New energymeter.TR1 element=Transformer.TR1 term= 1'

    #%%
    
    Data_PV['bax'] = []
    Data_PV['bax_battery'] = []
    Data_PV['bax_battery_rec'] = []
    Data_PV['baxe'] = []
    Data_PV['baxe_battery'] = []
    Data_PV['PV_list'] =[]
    Data_PV['PV_list2'] =[]
    Data_PV['PVShape_list'] =[]
#    seed(1)
    seed(x_seed[iMC])
    
    Data_Customers['Customers_quant'].append(math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100))
    Data_PV['PVquant'] = (np.around(Data_Case['PerPVSize_data']*round(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100)))
    Data_PV['PVquantnr'] = Data_Case['PerPVSize_data']*math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100)
    Data_PV['Bb'] = sample(sequence, math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100))#.astype(numpy.int64))
    Data_PV['indmaxnr'] = []
    Data_PV['PVqtt'] = [0]*len(Data_PV['PVquant'])
    if sum(Data_PV['PVquant']) > sum(Data_PV['PVquantnr']) or sum(Data_PV['PVquant']) < sum(Data_PV['PVquantnr']):    
        for ier in range(1,len(Data_PV['PVquantnr'])+1):
            Data_PV['indmaxnr'].append(heapq.nlargest(ier, range(len(Data_PV['PVquantnr'])), Data_PV['PVquantnr'].__getitem__))
            if sum(Data_PV['PVqtt']) < math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100):
                for iet in range(len(Data_PV['indmaxnr'][ier-1])):
                    Data_PV['PVqtt'][Data_PV['indmaxnr'][ier-1][iet]]=math.ceil(Data_PV['PVquantnr'][Data_PV['indmaxnr'][ier-1][iet]])                
            if sum(Data_PV['PVqtt']) == math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100):
                continue
        Data_PV['PVquant']=Data_PV['PVqtt']           
    if sum(Data_PV['PVquant']) > len(Data_Customers['PVS_n']) or sum(Data_PV['PVquant']) > math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100):
        for ier in range(len(Data_PV['PVquant'])):
            if sum(Data_PV['PVquant']) > math.ceil(len(Data_Customers['PVS_n'])*Data_Impact['PerPen'][iep]/100):
                Data_PV['indmaxnr']=np.argmax(Data_PV['PVquant'])
                Data_PV['PVquant'][Data_PV['indmaxnr']] -= 1  
    Data_PV['PVquant'] = numpy.uint64(Data_PV['PVquant'])         
    for ti in range(len(Data_PV['PVquant'])):
         Data_PV['bax'].extend([Data_Case['PVSize_data'][ti]]*Data_PV['PVquant'][ti])  
         Data_PV['bax_battery'].extend([Data_Case['BatterySize_data'][ti]]*Data_PV['PVquant'][ti])#,Data_Case['BatteryMaxRate_data'][ti]])  
         Data_PV['bax_battery_rec'].extend([Data_Case['BatteryMaxRate_data'][ti]]*Data_PV['PVquant'][ti])
    Data_PV['PVquant_save'].append(Data_PV['PVquant'])             
    Data_PV['baxe'].append([Data_PV['Bb'],Data_PV['bax']])
    Data_PV['baxe_battery'].append([Data_PV['bax_battery_rec'],Data_PV['bax_battery']])
    Data_PV['baxe_save'].append(Data_PV['baxe'])
    Data_PV['baxe_battery_save'].append(Data_PV['baxe_battery'])
    Data_PV['Bb_loc'].append(Data_PV['Bb']) 
    Data_Customers['Custom_history'].append(Data_Customers['Customers_quant'])
#    
    DSSText.Command = 'New Loadshape.Storage_Shape npts='+ str(Data_Case['hours'])+\
                ' interval=0.0833 mult=(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Storage4.csv useactual=false' 
    DSSText.Command = 'New Loadshape.PVShape_X npts=288 interval=0.0833 '+ \
    'mult=(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Norm_PV_Prof\\Nprofile_0.csv) useactual=false'
    
    exec(open(mydir +'/'+'3ph_restriction_users.py').read())
    
    for ipv in range(len(Data_PV['baxe'][0][1])):
        
        DSSText.Command = 'New Loadshape.PVShape_' + str(Data_PV['baxe'][0][0][ipv]) +' npts='+ str(Data_Case['hours'])+ ' interval=0.0833 mult='+\
        str(PVprofiles)+ str(Data_PV['baxe'][0][0][ipv]) +'.csv) useactual=false'
        Data_PV['PVShape_list'].append('New Loadshape.PVShape_' + str(Data_PV['baxe'][0][0][ipv]) +' npts='+ str(Data_Case['hours'])+\
               ' interval=0.0833 mult='+str(PVprofiles) + str(Data_PV['baxe'][0][0][ipv]) +'.csv) useactual=false')
            
        if Data_PV['baxe'][0][1][ipv] >= Data_Case['PV_minH']:
            
            DSSText.Command = 'New Generator.PV' + str(Data_PV['baxe'][0][0][ipv]) + ' ' + str(Nodes_pvs[Data_PV['baxe'][0][0][ipv]]) +\
            ' ' + str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]]) + ' ' + str(phases_pv[Data_PV['baxe'][0][0][ipv]]) +\
            ' kw='+str(Data_PV['baxe'][0][1][ipv]) +' kva='+str(Data_PV['baxe'][0][1][ipv]) +' pf=1'+' model=7 status=variable daily=PVShape_' +str(Data_PV['baxe'][0][0][ipv])
            Data_PV['PV_list'].append('New Generator.PV' + str(Data_PV['baxe'][0][0][ipv]) + ' ' + str(Nodes_pvs[Data_PV['baxe'][0][0][ipv]]) +\
            ' ' + str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]]) + ' ' + str(phases_pv[Data_PV['baxe'][0][0][ipv]]) +\
            ' kw='+str(Data_PV['baxe'][0][1][ipv]) +' kva='+str(Data_PV['baxe'][0][1][ipv]) +' pf=1'+' model=7 status=variable daily=PVShape_' +str(Data_PV['baxe'][0][0][ipv]))
            #descomentar para baterias
#            DSSText.Command = 'New Loadshape.Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])+' npts='+ str(Data_Case['hours'])+\
#                ' interval=0.0833 mult=(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Storage4.csv useactual=false' 
#            DSSText.Command ='New Storage.BatteryPV' + str(Data_PV['baxe'][0][0][ipv]) +' ' \
#                            + str(Nodes_pvs[Data_PV['baxe'][0][0][ipv]])+' ' \
#                            + str(phases_pv[Data_PV['baxe'][0][0][ipv]])+' '\
#                            +str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]])+' kwrated='+\
#                            str(Data_PV['baxe_battery'][0][0][ipv])+' pf=1 model=1 kwhrated='+\
#                            str(Data_PV['baxe_battery'][0][1][ipv])+' %reserve='+str(Data_Case['Battery_minSoC'])+\
#                            ' %stored='+str(Data_Case['Battery_refSoC_ini'])+' dispmode=follow daily=Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])
#            Data_PV['PV_list2'].append(['PV' + str(Data_PV['baxe'][0][0][ipv]),Data_PV['baxe'][0][0][ipv],'New Storage.BatteryPV' + str(Data_PV['baxe'][0][0][ipv]) +' ' \
#                            + str(Nodes_pvs[Data_PV['baxe'][0][0][ipv]])+' ' \
#                            + str(phases_pv[Data_PV['baxe'][0][0][ipv]])+' '\
#                            +str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]])+' kwrated='+\
#                            str(Data_PV['baxe_battery'][0][0][ipv])+' pf=1 model=1 kwhrated='+\
#                            str(Data_PV['baxe_battery'][0][1][ipv])+' %reserve='+str(Data_Case['Battery_minSoC'])+\
#                            ' %stored='+str(Data_Case['Battery_refSoC_ini'])+' dispmode=follow daily=Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])])
            
        
        else:
            DSSText.Command = 'New Generator.PV' + str(Data_PV['baxe'][0][0][ipv]) + ' ' + str(Data_Customers['PVS_n'][3][Data_PV['baxe'][0][0][ipv]]) +\
            ' ' + str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]]) + ' ' + str(Data_Customers['PVS_n'][2][Data_PV['baxe'][0][0][ipv]]) +\
            ' kw='+str(Data_PV['baxe'][0][1][ipv]) +' kva='+str(Data_PV['baxe'][0][1][ipv]) +' pf=1'+' model=1 status=variable daily=PVShape_' +str(Data_PV['baxe'][0][0][ipv])
            Data_PV['PV_list'].append( 'New Generator.PV' + str(Data_PV['baxe'][0][0][ipv]) + ' ' + str(Data_Customers['PVS_n'][3][Data_PV['baxe'][0][0][ipv]]) +\
            ' ' + str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]]) + ' ' + str(Data_Customers['PVS_n'][2][Data_PV['baxe'][0][0][ipv]]) +\
            ' kw='+str(Data_PV['baxe'][0][1][ipv]) +' kva='+str(Data_PV['baxe'][0][1][ipv]) +' pf=1'+' model=1 status=variable daily=PVShape_' +str(Data_PV['baxe'][0][0][ipv]))
            
            #descomentar para baterias
#            DSSText.Command = 'New Loadshape.Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])+' npts='+ str(Data_Case['hours'])+\
#                ' interval=0.0833 mult=(file=C:\\Users\\Username\\casos\\Profiles\\LCTProfiles\\Storage4.csv useactual=false' 
#            DSSText.Command ='New Storage.BatteryPV' + str(Data_PV['baxe'][0][0][ipv]) +' ' \
#                            + str(Data_Customers['PVS_n'][3][Data_PV['baxe'][0][0][ipv]])+' ' \
#                            + str(Data_Customers['PVS_n'][2][Data_PV['baxe'][0][0][ipv]])+' '\
#                            +str(Data_Customers['PVS_n'][4][Data_PV['baxe'][0][0][ipv]])+' kwrated='+\
#                            str(Data_PV['baxe_battery'][0][0][ipv])+' pf=1 model=1 kwhrated='+\
#                            str(Data_PV['baxe_battery'][0][1][ipv])+' %reserve='+str(Data_Case['Battery_minSoC'])+\
#                            ' %stored='+str(Data_Case['Battery_refSoC_ini'])+' dispmode=follow daily=Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])
#            Data_PV['PV_list2'].append(['PV' + str(Data_PV['baxe'][0][0][ipv]),Data_PV['baxe'][0][0][ipv],'New Storage.BatteryPV' + str(Data_PV['baxe'][0][0][ipv]) +' ' \
#                            + str(Data_Customers['PVS_n'][2][Data_PV['baxe'][0][0][ipv]])+' ' \
#                            + str(Data_Customers['PVS_n'][3][Data_PV['baxe'][0][0][ipv]])+' '\
#                            +str(Data_Customers['PVS_n'][6][Data_PV['baxe'][0][0][ipv]])+' kwrated='+\
#                            str(Data_PV['baxe_battery'][0][0][ipv])+' pf=1 model=1 kwhrated='+\
#                            str(Data_PV['baxe_battery'][0][1][ipv])+' %reserve='+str(Data_Case['Battery_minSoC'])+\
#                            ' %stored='+str(Data_Case['Battery_refSoC_ini'])+' dispmode=follow daily=Storage_Shape'+str(Data_PV['baxe'][0][0][ipv])])
##        

               
        #%%
    Data_PV['pv_list_all'].append(Data_PV['PV_list'])
    

    #%%
   
    #% Mode and reset
    DSSText.Command = 'Set VoltageBases = [115,69,34.5,13.8,7.9674]'   #calcular voltajes en pu
    DSSText.Command = 'calcv'
    #control mode
    DSSText.Command = 'Set ControlMode = time'
    DSSText.Command = 'Reset'                                                      #    resetting all energy meters and monitors
    DSSText.Command = 'set mode = daily stepsize=300s number=1'
#        
    import ExtractMonitorData as emd        
    ##solve
    Data_Voltage['Buses_VmagPu'] = []
    Data_Voltage['Vmax_Buses_VmagPu'] = []
    Data_Voltage['Vmax_Buses_VmagPu_loc'] = []
    Data_Current['Iut_maxim'] = []
    Data_Current['Line_Losses_wq'] = []
    Data_Current['Iut_mag'] = []
    Data_Current['Iut_normamps'] = []
    Data_Current['Iut_normampsMAX'] = []
    Data_Current['I_customer_amps'] = []
    Data_Current['I_PV_amps'] = []
    Data_Current['I_net_amps'] = []
    Data_Meters_SE['EMvalues'] = []
    Data_Meters_SE['Emeter_v'] = []
    Data_Meters_SE['EM'] = []
    Data_Meters_SE['Tap_1'] = []
    Data_Meters_SE['FPa_GENM'] = []
    Data_PV['pv-load_kw_1']=[]
    Data_PV['pv-load_kw'] = []
    Data_PV['pv-rec_kw'] = []
    Data_PV['pv-rec_kw_1'] = []
    Data_PV['battery_SoC'] = []
    Data_PV['battery_SoC_1'] = []
    Data_PV['battery_beta'] = []
    Data_PV['battery_beta_1'] = []
    Data_PV['battery_droop'] = []
    Data_PV['battery_droop_1'] = []
    Data_PV['pv_average'] = []
    Data_PV['pv_average_1'] = []
    Data_PV['p_proposed'] = []
    Data_PV['p_proposed_1'] = []
    Data_PV['p_proposed_bess'] = []
    Data_PV['p_proposed_bess_1'] = []
    Data_PV['battery_SoC2'] = []
    Data_PV['battery_SoC2_1'] = []
    Data_PV['battery_save_state'] = []
    Data_PV['battery_save_state_1'] = []
    Data_PV['battery_save_bess'] = []
    Data_PV['battery_save_bess_1'] = []
    battery_kwrated=[]
    beta_ini = np.zeros(np.shape(Data_PV['Bb']))
#    for istorage in range(len(Data_PV['Bb'])): 
#            opendss.DSSCircuit.SetActiveElement('storage.batterypv'+str(Data_PV['baxe'][0][0][istorage]))
#            Data_PV['battery_save_state'].append(float(opendss.DSSCircuit.ActiveCktElement.Properties('%stored').val))
#            Data_PV['battery_save_bess'].append(-1*float(opendss.DSSCircuit.ActiveCktElement.Properties('kw').val))
#            battery_kwrated.append(float(opendss.DSSCircuit.ActiveCktElement.Properties('kwrated').val))
    GenMult=GenMult1
#    Vu3phmax = []
    Vu3phmax_save_1 = []
    Vu3phmax_save_max=[]

#    print(Data_PV['battery_save_state'])
    #%%
    shape_calc_day=[]
    shape_calc_1=[]
    for ie in range(0,Data_Case['hours']):
#    for ie in range(0,220):
        
        if ie > 0:
            if Data_Impact['PerPen'][0] > 0:
#                opendss.DSSCircuit.Generators.name='PV68'
                opendss.DSSCircuit.LoadShapes.name='pvshape_X'
                if opendss.DSSCircuit.LoadShapes.Pmult[ie] > 0:
                #control 
                    exec(open(mydir +'/'+'Control_rating_UR.py').read())
        
        if GenMult > 1:
            GenMult=1
            
        DSSText.Command = 'Set Loadmult='+str(LoadMult)
        DSSText.Command = 'Set Genmult='+str(GenMult)
        
        
#        exec(open(mydir +'/'+'Battery_forecast_Ind.py').read())        

        DSSObj.ActiveCircuit.Solution.Solve()  #                
        
                
        Data_Meters_SE['FPa_GENM'].append(GenMult)  
#        
#            
#        # cálculo de desbalance de voltaje 3ph
        exec(open(mydir +'/'+'Calculate_NEMA_UR.py').read())
#                
#        #calcular corrientes
#        
        Data_Current['Iut_max'] = []
        Data_Current['Iut'] = []
        Data_Current['Iut_max_normamps'] = []
        Data_Current['I_customer'] = []
        Data_Current['I_PV'] = []
        
#        
        for ilines in range(len(Data_Customers['Lines_n'])):
            opendss.DSSCircuit.SetActiveElement(Data_Customers['Lines_n'][1][ilines])
            opendss.DSSCircuit.ActiveCktElement.CurrentsMagAng
            Ia = DSSCircuit.ActiveCktElement.CurrentsMagAng[0]
            Ib = DSSCircuit.ActiveCktElement.CurrentsMagAng[2]
            Ic = DSSCircuit.ActiveCktElement.CurrentsMagAng[4]
            line_normamps=opendss.DSSCircuit.Lines.EmergAmps
            Data_Current['Iut_max_normamps'].append(np.multiply(max([Ia,Ib,Ic]),100/line_normamps))
            Data_Current['Iut_max'].append(max([Ia,Ib,Ic]))
            Data_Current['Iut'].append([Ia,Ib,Ic])
            
##                
        Data_Current['Iut_normampsMAX'].append(np.max(Data_Current['Iut_max_normamps']))
        Data_Current['Iut_normamps'].append(Data_Current['Iut_max_normamps'])#        
        Data_Voltage['Buses_VmagPu'].append(opendss.DSSCircuit.AllBusVmagPu)
        Data_Voltage['Vmax_Buses_VmagPu'].append(max(max(Data_Voltage['Buses_VmagPu'])))
        Data_Voltage['Vmax_Buses_VmagPu_loc'].append(np.argmax(max(Data_Voltage['Buses_VmagPu'])))
        Data_Meters_SE['Emeter_v'].append(DSSCircuit.Meters.RegisterValues)
        MS=emd.ExtractMonitorData(DSSCircuit, 'SE')
        Y=MS[:,3]+MS[:,5]+MS[:,7]
        X=MS[:,2]+MS[:,4]+MS[:,6]
        Z=np.sqrt(X**2+Y**2)
        Vu3phmax_save_1.append(Vu3phmax)
        

    Data_Current['Iut_normampsMAX_save'].append(np.max(Data_Current['Iut_normampsMAX']))
    Data_PV['Bess_SoC'].append(Data_PV['battery_SoC_1'])  
    Data_Meters_SE['Tap_change'].append([emd.ExtractMonitorData(DSSCircuit, 'TapTR1')[:,2],\
                  (np.diff(emd.ExtractMonitorData(DSSCircuit, 'TapTR1')[:,2])!=0).sum()])
    Data_Meters_SE['EM_se'].append([Z,X,Y]) 
    Data_Current['I_PV_amps_save'].append(Data_Current['I_PV_amps'])
    Data_Meters_SE['FPa_GENM_all'].append(Data_Meters_SE['FPa_GENM'])
    Data_Current['Iut_normamps_save'].append(Data_Current['Iut_normamps'])
    Data_Meters_SE['EMvalues'].append(DSSCircuit.Meters.RegisterValues)
    Data_Voltage['Voltage_Profile_all'].append(Data_Voltage['Buses_VmagPu'])
    Data_Voltage['VMax_mag_MC'].append(Data_Voltage['Vmax_Buses_VmagPu'])  
    Data_Voltage['VMax_mag_MC_loc'].append(Data_Voltage['Vmax_Buses_VmagPu_loc'])
    Data_Voltage['Vmax_bus'].append(np.max(Data_Voltage['Buses_VmagPu']))
    Data_Voltage['Vmax_bus_location'].append(np.argmax(max(Data_Voltage['Buses_VmagPu']))) 
    Data_Voltage['Vmin_bus'].append(np.min(Data_Voltage['Buses_VmagPu']))
    Data_Voltage['Vmin_bus_location'].append(np.argmin(min(Data_Voltage['Buses_VmagPu']))) 
    Data_Meters_SE['EMeters'].append(Data_Meters_SE['EMvalues'])
    Data_Meters_SE['Emeter_v_prin'].append(Data_Meters_SE['Emeter_v'])
#    Vu3phmax_save.append(Vu3phmax)
    Vu3phmax_save.append(Vu3phmax_save_1)
#    print(np.max(Vu3phmax_save),np.max(Data_Current['Iut_normampsMAX']), Data_Impact['PerPen'][iep])
    shape_calc_day.append(shape_calc_1)
    Vu3phmax_max_save.append(np.max(Vu3phmax_save_1))
#    print(max(Vu3phmax),np.max(Data_Current['Iut_normampsMAX']), Data_Impact['PerPen'][iep])
exec(open(mydir +'/'+'Estimate_HC_UR_v.py').read())


Data_HC['HC_V_history'].append(Data_HC['subdict']['HC_voltage'])
Data_HC['HC_Vav_history'].append(Data_HC['subdict']['HC_voltage_av'])
Data_HC['HC_perstd_max_history'].append(Data_HC['subdict']['HC_percen_max_custom'])
Data_HC['HC_perstdav_max_history'].append(Data_HC['subdict']['HC_percen_max_custom_av'])
Data_HC['HC_V_history_min'].append(Data_HC['HC_voltage_min'])
Data_HC['HC_Vav_history_min'].append(Data_HC['HC_voltage_av_min'])
Data_HC['HC_perstd_max_history_min'].append(Data_HC['HC_percen_max_custom_min'])
Data_HC['HC_perstdav_max_history_min'].append(Data_HC['HC_percen_max_custom_av_min']) 
Data_HC['HC_perstd_max_history_UR'].append(Data_HC['subdict']['HC_percen_max_custom_UR'])
VoltageFlagmin_hist.append(VoltageFlagmin)
VoltageFlagmax_hist.append(VoltageFlagmax)
CurrentFlag_hist.append(CurrentFlag)
Data_Meters_SE['EMeters_history'].append(Data_Meters_SE['EMeters'])
#Data_Current['Iut_normamps_history'].append(Data_Current['Iut_normamps_save'])
Data_PV['PVquant_history'].append(Data_PV['PVquant_save'])  
Data_Voltage['Vmax_bus_history'].append(Data_Voltage['Vmax_bus'])
Data_Voltage['Vmin_bus_history'].append(Data_Voltage['Vmin_bus'])
Data_PV['PerPen_history'].append((Data_Impact['PerPen']))
Data_Current['Iut_normampsMAX_history'].append(Data_Current['Iut_normampsMAX_save'])
#Data_PV['Bess_SoC_history'].append(Data_PV['Bess_SoC'])
#Data_Voltage['Vprof_all'].append(Data_Voltage['Voltage_Profile_all'])
#Vprof_all
#Vu3phmax_history.append(Vu3phmax_save)
Vu3phmax_history.append(Vu3phmax_max_save)
Data_PV['pv_list_history'].append(Data_PV['pv_list_all'])
Data_PV['Bb_loc_history'].append(Data_PV['Bb_loc'])
average_vri.append(np.average(Data_ABB_iMC_custom['ABB_iMC_custom_problems']))
