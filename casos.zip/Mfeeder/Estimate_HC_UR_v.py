# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 14:25:53 2019

@author: lanal
"""
# Disctionaries
Data_ABB_iMC=dict([\
                   ['ABB_iMC', []],\
                   ['ABB', []],\
                   ['AB', []],\
                   ['ABB_iMC_UR', []],\
                   ['ABB_UR', []],\
                   ['AB_UR', []],\
                   ['BusVarray', []],\
                   ['BusVarray_UR', []],\
                   ])

Data_Vmax_location=dict([\
                         ['Vmax_location', []],\
                         ['Distance_vmax_loc', []],\
                         ['Vmax_location_history', []],\
                         ])

Data_ABB_std=dict([\
                   ['ABB_iMC_std', []],\
                   ['ABB_iMC_std_pen', []],\
                   ['ABB_iMC_std_1', []],\
                   ['ABB_iMC_std_average', []],\
                   ['ABB_iMC_std_UR', []],\
                   ['ABB_iMC_std_pen_UR', []],\
                   ['ABB_iMC_std_1_UR', []],\
                   ['ABB_iMC_std_average_UR', []],\
                   ])   

Data_ABB_iMC_custom_perquant=dict([\
                                   ['Quant_history', []],\
                                   ['Quant_history_min', []],\
                                   ['Percen_history', []],\
                                   ['Percen_history_min', []],\
                                   ['Index_history', []],\
                                   ['Index_history_min', []],\
                                   ['customers_problems', []],\
                                   ['index_daily', []],\
                                   ['day_problems', []],\
                                   ['index_2', []],\
                                   ['problems_quant', []],\
                                   ['problems_percen', []],\
                                   ['index_1', []],\
                                   ])    

Data_ABB_iMC_custom=dict([\
                          ['ABB_iMC_custom_problems', []],\
                          ['ABB_iMC_custom_problems-min', []],\
                          ['ABB_iMC_custom_issues', []],\
                          ['ABB_iMC_custom_issues-min', []],\
                          ['problems_quant', []],\
                          ['problems_quant-min', []],\
                          ['customer_compliment_issues', []],\
                          ['customer_compliment_issues_1', []],\
                          ['customer_compliment_issues_1-min', []],\
                          ['customer_compliance_1', []],\
                          ['customer_compliance_1-min', []],\
                          ['customer_compliance_zero', []],\
                          ['customer_compliance_zero-min', []],\
                          ['customer_compliance', []],\
                          ['customer_compliance-min', []],\
                          ['day_problems', []],\
                          ['day_problems-min', []],\
                          ['average_daily', []],\
                          ['average_daily-min', []],\
                          ['customers_problems', []],\
                          ['customers_problems-min', []],\
                          ['no_compliment', []],\
                          ['no_compliment-min', []],\
                          ['customer_nocompliment_arg', []],\
                          ['ABB_iMC_custom_index', []],\
                          ['ABB_iMC_custom_index-min', []],\
                          ['customer_nocompliment_arg_1', []],\
                          ['customer_nocompliment_arg_1-min', []],\
                          ['nocompliment_arg', []],\
                          ['nocompliment_arg-min', []],\
                          ['ABB_iMC_custom_problems_UR', []],\
                          ['ABB_iMC_custom_issues_UR', []],\
                          ['problems_quant_UR', []],\
                          ['customer_compliment_issues_UR', []],\
                          ['customer_compliment_issues_1_UR', []],\
                          ['customer_compliance_1_UR', []],\
                          ['customer_compliance_zero_UR', []],\
                          ['customer_compliance_UR', []],\
                          ['day_problems_UR', []],\
                          ['average_daily_UR', []],\
                          ['customers_problems_UR', []],\
                          ['no_compliment_UR', []],\
                          ['customer_nocompliment_arg_UR', []],\
                          ['ABB_iMC_custom_index_UR', []],\
                          ['customer_nocompliment_arg_1_UR', []],\
                          ['nocompliment_arg_UR', []],\
                          ]) 

  

Data_HC['subdict']=dict([\
              ['Current_Flags', []],\
              ['HC_voltage', []],\
              ['HC_voltage_av', []],\
              ['HC_percen_max_custom', []],\
              ['HC_percen_max_custom_UR', []],\
              ['HC_percen_max_custom_av', []],\
              ['HC_voltage', []],\
              ['HC_voltage_Impact', []],\
              ['HC_voltage_Impact_min', []],\
              ['HC_current_Impact', []],\
              ['HC_Substation_Impact', []],\
              ])    
Data_HC['subdict']['HC_voltage_Impact']=dict([\
                              ['Total GD installed', []],\
                              ['GD average per customer', []],\
                              ['Maximum Voltage (pu)', []],\
                              ['% GD Penetration', []],\
                              ['Index Time Issue', []],\
                              ['Maximum % customer with issues', []],\
                              ['Index Customer Issue', []],\
                              ['Customer Distance from Substation', []],\
                              ])  
Data_HC['subdict']['HC_voltage_Impact_min']=dict([\
                              ['Total GD installed', []],\
                              ['GD average per customer', []],\
                              ['Maximum Voltage (pu)', []],\
                              ['% GD Penetration', []],\
                              ['Index Time Issue', []],\
                              ['Maximum % customer with issues', []],\
                              ['Index Customer Issue', []],\
                              ['Customer Distance from Substation', []],\
                              ])  
Data_HC['subdict']['Current_Flags']=dict([\
                              ['% Line Utilization', []],\
                              ['MC Case', []],\
                              ['% GD penetration', []],\
                              ['Index Time', []],\
                              ['Index Customer', []],\
                              ])  

Data_HC['Voltage_Flags']=dict([\
                              ['MC Case', []],\
                              ['% GD penetration', []],\
                              ['Index Time', []],\
                              ]) 

#%% save just the customers voltages
for irf in range(len(Data_Voltage['Voltage_Profile_all'])):
    Data_ABB_iMC['ABB'] = []
    for irt in range(len(Data_Voltage['Voltage_Profile_all'][irf])):
        Data_ABB_iMC['BusVarray'] = []
        for ii in range(len(Data_Customers['NodeNames_BusV'])):
            Data_ABB_iMC['BusVarray'].append(Data_Voltage['Voltage_Profile_all'][irf][irt][Data_Customers['NodeNames_BusV'][ii]])
        Data_ABB_iMC['ABB'].append(Data_ABB_iMC['BusVarray'])
    Data_ABB_iMC['ABB_iMC'].append(Data_ABB_iMC['ABB'])
    
# save customers voltage issues distances    
for i in range(len(Data_Voltage['VMax_mag_MC_loc'])):
    Data_Vmax_location['Vmax_location'] = []
    for ii in range(len(Data_Voltage['VMax_mag_MC_loc'][i])):
        Data_Vmax_location['Vmax_location'].append(Data_Customers['all_node_distances'][Data_Voltage['VMax_mag_MC_loc'][i][ii]])
    Data_Vmax_location['Vmax_location_history'].append(Data_Vmax_location['Vmax_location'])
    
#%% change resolution for EN STD EN 50160 this code depends from the country std       
for ii in range(len(Data_ABB_iMC['ABB_iMC'])):
    Data_ABB_std['ABB_iMC_std_1'] = []
    for iii in range(0,len(Data_ABB_iMC['ABB_iMC'][ii]),int(Data_Case['Resolution_std-data'][0]/Data_Case['Resolution_std-data'][1])):             
        Data_ABB_std['ABB_iMC_std_average'] = []
        for iv in range(0,len(Data_ABB_iMC['ABB_iMC'][ii][iii])):  
            if iv < len(Data_ABB_iMC['ABB_iMC'][ii][iii]):
                Data_ABB_std['ABB_iMC_std_average'].append((Data_ABB_iMC['ABB_iMC'][ii][iii][iv]+Data_ABB_iMC['ABB_iMC'][ii][iii+1][iv])/int(Data_Case['Resolution_std-data'][0]/Data_Case['Resolution_std-data'][1]))
        Data_ABB_std['ABB_iMC_std_1'].append(Data_ABB_std['ABB_iMC_std_average'])
    Data_ABB_std['ABB_iMC_std'].append(Data_ABB_std['ABB_iMC_std_1'])

# UR 2% CFE L-000070    
for ii in range(len(Vu3phmax_save)):
    Data_ABB_std['ABB_iMC_std_1_UR'] = []
    for iii in range(0,len(Vu3phmax_save[ii]),int(Data_Case['Resolution_std-data'][0]/Data_Case['Resolution_std-data'][1])):             
        Data_ABB_std['ABB_iMC_std_average_UR'] = []
        for iv in range(0,len(Vu3phmax_save[ii][iii][0])):  
            if iv < len(Vu3phmax_save[ii][iii][0]):
                Data_ABB_std['ABB_iMC_std_average_UR'].append((Vu3phmax_save[ii][iii][0][iv]+Vu3phmax_save[ii][iii+1][0][iv])/int(Data_Case['Resolution_std-data'][0]/Data_Case['Resolution_std-data'][1]))
        Data_ABB_std['ABB_iMC_std_1_UR'].append(Data_ABB_std['ABB_iMC_std_average_UR'])
    Data_ABB_std['ABB_iMC_std_UR'].append(Data_ABB_std['ABB_iMC_std_1_UR'])    
    
#%% customers issues compliment and no compliment       
for ii in range(len(Data_ABB_std['ABB_iMC_std'])):
    Data_ABB_iMC_custom['day_problems'] = []
    Data_ABB_iMC_custom['average_daily'] = []
    Data_ABB_iMC_custom['customer_compliment_issues_1'] = [0]*(len(Data_Customers['PVS_n']))  
    Data_ABB_iMC_custom['day_problems-min'] = []
    Data_ABB_iMC_custom['average_daily-min'] = []
    Data_ABB_iMC_custom['customer_compliment_issues_1-min'] = [0]*(len(Data_Customers['PVS_n']))  
    for iii in range(len(Data_Customers['NodeNames_BusV'])):
        Data_ABB_iMC_custom['customers_problems'] = 0
        Data_ABB_iMC_custom['customers_problems-min'] = 0
        for iv in range(len(Data_ABB_std['ABB_iMC_std'][ii])):
            if Data_ABB_std['ABB_iMC_std'][ii][iv][iii] >= Data_Case['Vlimit_pu'][1] or Data_ABB_std['ABB_iMC_std'][ii][iv][iii] <= Data_Case['Vlimit_pu'][0]:
                Data_ABB_iMC_custom['customers_problems'] += 1
                Data_ABB_iMC_custom['customer_compliment_issues_1'][iii] = 1
#            if Data_ABB_std['ABB_iMC_std'][ii][iv][iii] <= Data_Case['Vlimit_pu'][0]:
                Data_ABB_iMC_custom['customers_problems-min'] += 1
                Data_ABB_iMC_custom['customer_compliment_issues_1-min'][iii] = 1
        Data_ABB_iMC_custom['day_problems'].append(Data_ABB_iMC_custom['customers_problems'])
        Data_ABB_iMC_custom['day_problems-min'].append(Data_ABB_iMC_custom['customers_problems-min'])
    Data_ABB_iMC_custom['ABB_iMC_custom_issues'].append(Data_ABB_iMC_custom['customer_compliment_issues_1'])
    Data_ABB_iMC_custom['ABB_iMC_custom_issues-min'].append(Data_ABB_iMC_custom['customer_compliment_issues_1-min'])
    Data_ABB_iMC_custom['problems_quant'].append(Data_ABB_iMC_custom['day_problems'])
    Data_ABB_iMC_custom['problems_quant-min'].append(Data_ABB_iMC_custom['day_problems-min'])
    Data_ABB_iMC_custom['ABB_iMC_custom_problems'].append(np.multiply(Data_ABB_iMC_custom['problems_quant'][ii],100/len(Data_ABB_std['ABB_iMC_std'][ii])))
    Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'].append(np.multiply(Data_ABB_iMC_custom['problems_quant-min'][ii],100/len(Data_ABB_std['ABB_iMC_std'][ii])))
    
#UR RATIO 2%    
for ii in range(len(Data_ABB_std['ABB_iMC_std_UR'])):
    Data_ABB_iMC_custom['day_problems_UR'] = []
    Data_ABB_iMC_custom['average_daily_UR'] = []
    Data_ABB_iMC_custom['customer_compliment_issues_1_UR'] = [0]*(len(Data_Customers['all_bus_names']))  
    for iii in range(len(Data_ABB_std['ABB_iMC_std_UR'][ii][0])):
        Data_ABB_iMC_custom['customers_problems_UR'] = 0
        for iv in range(len(Data_ABB_std['ABB_iMC_std_UR'][ii])):
            if Data_ABB_std['ABB_iMC_std_UR'][ii][iv][iii] >= Data_Case['UR_Maxim%']:
                Data_ABB_iMC_custom['customers_problems_UR'] += 1
                Data_ABB_iMC_custom['customer_compliment_issues_1_UR'][iii] = 1
        Data_ABB_iMC_custom['day_problems_UR'].append(Data_ABB_iMC_custom['customers_problems_UR'])
    Data_ABB_iMC_custom['ABB_iMC_custom_issues_UR'].append(Data_ABB_iMC_custom['customer_compliment_issues_1_UR'])
    Data_ABB_iMC_custom['problems_quant_UR'].append(Data_ABB_iMC_custom['day_problems_UR'])
    Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'].append(np.multiply(Data_ABB_iMC_custom['problems_quant_UR'][ii],100/len(Data_ABB_std['ABB_iMC_std_UR'][ii])))
    


#%%
# extract index customer with problems   
for ii in range(len(Data_ABB_iMC_custom['ABB_iMC_custom_issues'])):
    Data_ABB_iMC_custom['nocompliment_arg'] = []
    Data_ABB_iMC_custom['customer_compliance_zero'] = [0]*(len(Data_Customers['PVS_n']))
    Data_ABB_iMC_custom['nocompliment_arg-min'] = []
    Data_ABB_iMC_custom['customer_compliance_zero-min'] = [0]*(len(Data_Customers['PVS_n']))
    for iii in range(len(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii])):
        if Data_ABB_iMC_custom['ABB_iMC_custom_issues'][ii][iii] == 1:
            Data_ABB_iMC_custom['nocompliment_arg'].append(iii)
            Data_ABB_iMC_custom['nocompliment_arg-min'].append(iii)
        if Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii][iii] >= (100-Data_Case['%-Cumplimiento-Tension']) or Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii][iii] >= (100-Data_Case['%-Cumplimiento-Tension']):
            Data_ABB_iMC_custom['customer_compliance_zero'][iii] = 1
            Data_ABB_iMC_custom['customer_compliance_zero-min'][iii] = 1

    Data_ABB_iMC_custom['ABB_iMC_custom_index'].append(Data_ABB_iMC_custom['nocompliment_arg'])
    Data_ABB_iMC_custom['customer_compliance'].append(Data_ABB_iMC_custom['customer_compliance_zero'])
    Data_ABB_iMC_custom['ABB_iMC_custom_index-min'].append(Data_ABB_iMC_custom['nocompliment_arg-min'])
    Data_ABB_iMC_custom['customer_compliance-min'].append(Data_ABB_iMC_custom['customer_compliance_zero-min'])
    
#UR 2%    
for ii in range(len(Data_ABB_iMC_custom['ABB_iMC_custom_issues_UR'])):
    Data_ABB_iMC_custom['nocompliment_arg_UR'] = []
    Data_ABB_iMC_custom['customer_compliance_zero_UR'] = [0]*(len(Data_Customers['all_bus_names']))
    for iii in range(len(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])):
        if Data_ABB_iMC_custom['ABB_iMC_custom_issues_UR'][ii][iii] == 1:
            Data_ABB_iMC_custom['nocompliment_arg_UR'].append(iii)
        if Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii][iii] >= (100-Data_Case['%-Cumplimiento-Tension']):
            Data_ABB_iMC_custom['customer_compliance_zero_UR'][iii] = 1
    Data_ABB_iMC_custom['ABB_iMC_custom_index_UR'].append(Data_ABB_iMC_custom['nocompliment_arg_UR'])
    Data_ABB_iMC_custom['customer_compliance_UR'].append(Data_ABB_iMC_custom['customer_compliance_zero_UR'])
    

#%%
Data_ABB_iMC_custom_perquant['problems_quant'] = []
Data_ABB_iMC_custom_perquant['problems_quant_min'] = []
Data_ABB_iMC_custom_perquant['problems_percen'] = []
Data_ABB_iMC_custom_perquant['problems_percen_min'] = []
Data_ABB_iMC_custom_perquant['index_1'] = []
Data_ABB_iMC_custom_perquant['index_1_min'] = []
for ii in range(len(Data_ABB_std['ABB_iMC_std'])):
    Data_ABB_iMC_custom_perquant['day_problems'] = []
    Data_ABB_iMC_custom_perquant['day_problems_min'] = []
    Data_ABB_iMC_custom_perquant['index_daily'] = []
    Data_ABB_iMC_custom_perquant['index_daily_min'] = []
    for iii in range(len(Data_ABB_std['ABB_iMC_std'][ii])):
        Data_ABB_iMC_custom_perquant['customers_problems'] = 0
        Data_ABB_iMC_custom_perquant['customers_problems_min'] = 0
        Data_ABB_iMC_custom_perquant['index_2'] = []
        Data_ABB_iMC_custom_perquant['index_2_min'] = []
        for iv in range(len(Data_ABB_std['ABB_iMC_std'][ii][iii])):
            if Data_ABB_std['ABB_iMC_std'][ii][iii][iv] >= Data_Case['Vlimit_pu'][1] or Data_ABB_std['ABB_iMC_std'][ii][iii][iv] <= Data_Case['Vlimit_pu'][0]:
                Data_ABB_iMC_custom_perquant['customers_problems'] += 1
                Data_ABB_iMC_custom_perquant['index_daily'].append(iv)
#            if Data_ABB_std['ABB_iMC_std'][ii][iii][iv] <= Data_Case['Vlimit_pu'][0]:
                Data_ABB_iMC_custom_perquant['customers_problems_min'] += 1
                Data_ABB_iMC_custom_perquant['index_daily_min'].append(iv)
        Data_ABB_iMC_custom_perquant['day_problems'].append(Data_ABB_iMC_custom_perquant['customers_problems'])
        Data_ABB_iMC_custom_perquant['day_problems_min'].append(Data_ABB_iMC_custom_perquant['customers_problems_min'])
        Data_ABB_iMC_custom_perquant['index_2'].append(Data_ABB_iMC_custom_perquant['index_daily'])
        Data_ABB_iMC_custom_perquant['index_2_min'].append(Data_ABB_iMC_custom_perquant['index_daily_min'])
    Data_ABB_iMC_custom_perquant['problems_quant'].append(Data_ABB_iMC_custom_perquant['day_problems'])
    Data_ABB_iMC_custom_perquant['problems_quant_min'].append(Data_ABB_iMC_custom_perquant['day_problems_min'])
    Data_ABB_iMC_custom_perquant['problems_percen'].append(np.multiply(Data_ABB_iMC_custom_perquant['problems_quant'][ii],100/len(Data_ABB_std['ABB_iMC_std'][ii][iii])))
    Data_ABB_iMC_custom_perquant['problems_percen_min'].append(np.multiply(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii],100/len(Data_ABB_std['ABB_iMC_std'][ii][iii])))    
    Data_ABB_iMC_custom_perquant['index_1'].append(Data_ABB_iMC_custom_perquant['index_2'])
    Data_ABB_iMC_custom_perquant['index_1_min'].append(Data_ABB_iMC_custom_perquant['index_2_min'])   

#%% HC estimation   
    
#for i in range(len(Data_Voltage['Vmax_bus'])):
Data_HC['subdict']['HC_voltage'] = []
Data_HC['subdict']['HC_voltage_av'] = []
Data_HC['subdict']['HC_percen_max_custom'] = []
Data_HC['subdict']['HC_percen_max_custom_UR'] = []
Data_HC['subdict']['HC_percen_max_custom_av'] = []
Data_HC['HC_voltage_min'] = []
Data_HC['HC_voltage_av_min'] = []
Data_HC['HC_percen_max_custom_min'] = []
Data_HC['HC_percen_max_custom_av_min'] = []
for ii in range(len(Data_Voltage['Vmax_bus'])):
    if Data_Voltage['Vmax_bus'][ii] >= Data_Case['Vlimit_pu'][1] and np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]) > 0:
        if ii > 0:
            Data_HC['subdict']['HC_voltage'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         Data_Voltage['Vmax_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmax_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),np.max(Data_Current['Iut_normamps_save'][ii-1]),Data_Impact['PerPen'][ii-1],\
                                         Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
        else:
            Data_HC['subdict']['HC_voltage'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         Data_Voltage['Vmax_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmax_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
    
        Data_HC['subdict']['HC_voltage_av'].append([Data_PV['PVquant_save'][ii],iMC,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n'])])
            
    if np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]) >= (100-Data_Case['%-Cumplimiento-Tension']):
        if ii > 0:
            Data_HC['subdict']['HC_percen_max_custom'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         Data_Voltage['Vmax_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmax_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant'][ii]),Data_Voltage['Vmin_bus'][ii],np.max(Data_Current['Iut_normamps_save'][ii-1]),Data_Impact['PerPen'][ii-1],\
                                         Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
        else:
            Data_HC['subdict']['HC_percen_max_custom'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         Data_Voltage['Vmax_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmax_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant'][ii]),Data_Voltage['Vmin_bus'][ii],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
            
        Data_HC['subdict']['HC_percen_max_custom_av'].append([Data_PV['PVquant_save'][ii],iMC,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n'])])
            
    if Data_Voltage['Vmin_bus'][ii] <= Data_Case['Vlimit_pu'][0] and np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]) > 0:
        if ii > 0:
            Data_HC['HC_voltage_min'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmin_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         Data_Voltage['Vmin_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmin_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),np.max(Data_Current['Iut_normamps_save'][ii-1]),Data_Impact['PerPen'][ii-1],\
                                         Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
        else:
            Data_HC['HC_voltage_min'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmin_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         Data_Voltage['Vmin_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmin_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
    
        Data_HC['HC_voltage_av_min'].append([Data_PV['PVquant_save'][ii],iMC,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n'])])
        
    if np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]) >= (100-Data_Case['%-Cumplimiento-Tension']):
        if ii > 0:
            Data_HC['HC_percen_max_custom_min'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmin_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         Data_Voltage['Vmin_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmin_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),Data_Voltage['Vmax_bus'][ii],np.max(Data_Current['Iut_normamps_save'][ii-1]),Data_Impact['PerPen'][ii-1],\
                                         Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
        else:
            Data_HC['HC_percen_max_custom_min'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmin_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems-min'][ii]),\
                                         Data_Voltage['Vmin_bus_location'][ii],\
                                         Data_Customers['all_node_distances'][Data_Voltage['Vmin_bus_location'][ii]],iMC,ii,np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         np.max(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),np.argmax(Data_ABB_iMC_custom_perquant['problems_quant_min'][ii]),Data_Voltage['Vmax_bus'][ii],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii,np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])])
    
        Data_HC['HC_percen_max_custom_av_min'].append([Data_PV['PVquant_save'][ii],iMC,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n'])])
        
        
    if np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]) >= (100-Data_Case['%-Cumplimiento-Tension']):
        if ii > 0:
            Data_HC['subdict']['HC_percen_max_custom_UR'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),\
                                         Data_Customers['all_bus_distances'][np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])],Data_Customers['all_bus_names'][np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])],iMC,ii,\
                                         Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],np.max(Data_Current['Iut_normamps_save'][ii]),np.max(Data_Current['Iut_normamps_save'][ii-1]),Data_Impact['PerPen'][ii-1],\
                                         Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii])
        else:
            Data_HC['subdict']['HC_percen_max_custom_UR'].append([Data_Impact['PerPen'][ii],Data_Voltage['Vmax_bus'][ii],\
                                         np.sum(Data_PV['PVquant_save'][ii]),np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                         np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii])),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems'][ii]),\
                                         np.max(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii]),\
                                         Data_Customers['all_bus_distances'][np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])],Data_Customers['all_bus_names'][np.argmax(Data_ABB_iMC_custom['ABB_iMC_custom_problems_UR'][ii])],iMC,ii,\
                                         Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],np.max(Data_Current['Iut_normamps_save'][ii]),\
                                         x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii])
 
    
#%%                                        
xcurr=[]
Data_HC['subdict']['Current_Flags']=[]
CurrentFlag=[]
lines_names=opendss.DSSCircuit.Lines.AllNames
for ii in range(len(Data_Current['Iut_normamps_save'])): 
    for iii in range(len(Data_Current['Iut_normamps_save'][ii])):
        for iv in range(len(Data_Current['Iut_normamps_save'][ii][iii])):
#            if (Data_Current['Iut_normamps_save'][ii][iii][iv] >= Data_Case['CurrentLimit_%'] and (Data_Current['Iut_normamps_save'][ii][iii][iv] <= 100)):
            if (Data_Current['Iut_normamps_save'][ii][iii][iv] >= Data_Case['CurrentLimit_%']+1 and (Data_Current['Iut_normamps_save'][ii][iii][iv] <= 100)):
                PerUtil=Data_Current['Iut_normamps_save'][ii][iii][iv]
                if ii > 0:
                    xcurr.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Current['Iut_normampsMAX_save'][ii-1],Data_Impact['PerPen'][ii-1],\
                                  Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii])
                else:
                    xcurr.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Meters_SE['EMeters'][ii][0][0],ii])

if xcurr == []:
    CurrentFlag=[]
else:
    CurrentFlag=min(xcurr)                  

#%%
     
xvolmax=[]
xvolmin=[]
Data_HC['Voltage_Flags']=[]
for ii in range(len(Data_Voltage['Voltage_Profile_all'])):#PENETRATION CASE
#    print(ii)
    for iii in range(len(Data_Voltage['Voltage_Profile_all'][ii])): #TIME STEPS
        for iv in range(len(Data_Voltage['Voltage_Profile_all'][ii][iii])): #NODES
            if ii > 0:
                if (Data_Voltage['Voltage_Profile_all'][ii][iii][iv] >= Data_Case['Vlimit_pu'][1] and Data_Voltage['Voltage_Profile_all'][ii][iii][iv] <= (Data_Case['Vlimit_pu'][1]+0.15)):
                    PerUtil=Data_Voltage['Voltage_Profile_all'][ii][iii][iv]
                    xvolmax.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Current['Iut_normampsMAX_save'][ii-1],Data_Impact['PerPen'][ii-1],\
                                  Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii])
                if (Data_Voltage['Voltage_Profile_all'][ii][iii][iv] <= Data_Case['Vlimit_pu'][0]):# and Data_Voltage['Voltage_Profile_all'][i][ii][iii][iv] >= (Data_Case['Vlimit_pu'][0]-0.001)):
                    PerUtil=Data_Voltage['Voltage_Profile_all'][ii][iii][iv]
                    xvolmin.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Current['Iut_normampsMAX_save'][ii-1],Data_Impact['PerPen'][ii-1],\
                                  Data_Voltage['Vmax_bus'][ii-1],Data_Voltage['Vmin_bus'][ii-1],x_seed[iMC],Data_Meters_SE['EMeters'][ii][0][0],ii])
            else:
                if (Data_Voltage['Voltage_Profile_all'][ii][iii][iv] >= Data_Case['Vlimit_pu'][1] and Data_Voltage['Voltage_Profile_all'][ii][iii][iv] <= (Data_Case['Vlimit_pu'][1]+0.15)):
                    PerUtil=Data_Voltage['Voltage_Profile_all'][ii][iii][iv]
                    xvolmax.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Meters_SE['EMeters'][ii][0][0],ii])
                if (Data_Voltage['Voltage_Profile_all'][ii][iii][iv] <= Data_Case['Vlimit_pu'][0]):# and Data_Voltage['Voltage_Profile_all'][i][ii][iii][iv] >= (Data_Case['Vlimit_pu'][0]-0.001)):
                    PerUtil=Data_Voltage['Voltage_Profile_all'][ii][iii][iv]
                    xvolmin.append([Data_Impact['PerPen'][ii],PerUtil,iMC,iii,iv,np.sum(Data_Case['PVSize_data']*np.array(Data_PV['PVquant_save'][ii]))/len(Data_Customers['PVS_n']),\
                                  Data_Voltage['Vmax_bus'][ii],Data_Voltage['Vmin_bus'][ii],Data_Current['Iut_normampsMAX_save'][ii],Data_Meters_SE['EMeters'][ii][0][0],ii])

if xvolmax == []:
    VoltageFlagmax=[]
else:
    VoltageFlagmax=min(xvolmax) 


if xvolmin == []:
    VoltageFlagmin=[]
else:
    VoltageFlagmin=min(xvolmin) 